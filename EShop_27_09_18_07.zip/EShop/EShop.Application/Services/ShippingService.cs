﻿using EShop.Application.Command;
using EShop.Application.Dto;
using EShop.Application.IServices;
using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Services
{
    public class ShippingService : IShippingService
    {
        private readonly IMediator _mediator;

        public ShippingService(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<ApiResponse<List<Dto.Shipping>>> GetShippingData(Dto.Shipping shiping)
        {
            List<Dto.Shipping> shippings = new List<Dto.Shipping>();

            var result = await _mediator.Send(new GetShippingAddressByIdQuery { CustomerId = shiping.CustomerId });
            return new ApiResponse<List<Dto.Shipping>>()
            {
                Data = shippings
            };
        }

        public async Task<ApiResponse<int>> InsertShippingAddress(Dto.Shipping shipping)
        {
            //convert shipping dto to entity 
            ShippingEntity shippingEntity = new ShippingEntity();
            CreateShippingCommand createShippingCommand = new CreateShippingCommand() { payload = shippingEntity };
            var order = await _mediator.Send(createShippingCommand);
            return new ApiResponse<int>
            {
                Data = order
            };
        }

    }
}
