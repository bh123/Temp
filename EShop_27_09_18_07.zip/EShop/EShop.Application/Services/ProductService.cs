﻿using EShop.Application.Command;
using EShop.Application.Command.Handler;
using EShop.Application.Dto;
using EShop.Application.IServices;
using EShop.Core.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop.Application.Services
{
    public class ProductService : IProductService
    {
        private readonly IMediator _mediator;

        public ProductService(IMediator mediator)
        {
            _mediator = mediator;
        }

        //public async Task<ApiResponse<int>> AddCartItems(Product product)
        //{
        //    List<ProductEntity> productEntities = new List<ProductEntity>();
        //    productEntities = await _mediator.Send(new GetProductByQuery());
        //    return result;
        //}

        public async Task<ApiResponse<List<Product>>> GetProductList()
        {
            List<Product> products = new List<Product>();
            var productentity = await _mediator.Send(new GetProductByQuery());
            //conver product entity to product
            return new ApiResponse<List<Product>>()
            {
                Data = products
            };

        }
    }
}
