﻿namespace EShop.Infrastructure.Consts
{
    public enum MembershipType
    {
        Membership = 0,
        NonMembership = 1
    }
}
