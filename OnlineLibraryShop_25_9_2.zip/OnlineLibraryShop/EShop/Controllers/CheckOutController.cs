﻿using EShop.Application.Command;
using EShop.Application.IServices;
using Microsoft.AspNetCore.Mvc;

namespace EShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CheckOutController : ControllerBase
    {
        private readonly ICheckOutService _checkOutService;
        private readonly IOrderService _orderService;

        public CheckOutController(ICheckOutService checkOutService, IOrderService orderService)
        {
            _checkOutService = checkOutService;
            _orderService = orderService;
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] CheckoutCommand command)
        {
            var orderid = await _checkOutService.Checkout(command);
             await _orderService.GenerateSlipIfRequired(orderid);
            return CreatedAtAction(nameof(Post), new { id = orderid }, new { GenerateOrderId = orderid });

        }
    }
}
