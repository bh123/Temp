using OnlineLibraryShop.Core.Entities;
using System.ComponentModel.DataAnnotations;
namespace EShop.Core.Entities
{
    public class PurchaseRequestDto
    {
        public int CustomerId { get; set; }
       
    }

    

}