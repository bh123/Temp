﻿using EShop.Application.Command;
using EShop.Application.Services;
using MediatR;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace OnlineLibraryShop_Test
{
    public class CheckOutServiceTests
    {
        [Fact]
        public async Task Checkout_Should_Invoke_Mediator_Send()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var checkoutService = new CheckOutService(mediatorMock.Object);
            var checkoutCommand = new CheckoutCommand();

            // Act
            await checkoutService.Checkout(checkoutCommand);

            // Assert
            mediatorMock.Verify(m => m.Send(checkoutCommand, It.IsAny<CancellationToken>()), Times.Once);
        }
    }
}
