﻿using EShop.Application.Command;
using EShop.Application.IServices;
using MediatR;

namespace EShop.Application.Services
{
    public class CheckOutService : ICheckOutService
    {
        private readonly IMediator _mediator;

        public CheckOutService(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<int> Checkout(CheckoutCommand checkoutCommand)
        {
            var result= await _mediator.Send(checkoutCommand);
            return result;
        }
    }
}
