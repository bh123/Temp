﻿using EShop.Application.Order;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop.Application.Command.Handler
{
    public class GetProductQueryHandler : IRequestHandler<Command.GetCartQueryHandler, List<Product>>
    {
        private readonly IProductRepository _productRepository;
        public GetProductQueryHandler(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public async Task<List<Product>> Handle(Command.GetCartQueryHandler request, CancellationToken cancellationToken)
        {
            var products = await _productRepository.GetProductList();
            return products;
        }

    }
}
