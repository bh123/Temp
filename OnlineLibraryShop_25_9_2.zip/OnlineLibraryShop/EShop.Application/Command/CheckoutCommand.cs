﻿using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Command
{
    public class CheckoutCommand : IRequest<int>
    {
        public int CustomerId { get; set; }
        public List<CartItemDto> Items { get; set; }
        public Shipping Shipping { get; set; }

    }
}
