﻿using EShop.Core.Entities;
using Microsoft.Extensions.Configuration;

namespace EShop.Application.Validation
{

    public class GenerateSlip : IGenerateSlip
    {

        private readonly IConfiguration _configuration;

        public GenerateSlip(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public void GeneratePdf(OrderDto order)
        {
            string fileName = "test.pdf";
            string generatedSlipPath = _configuration["FilePath:GeneratedSlipPath"];

            string GeneratedFile = generatedSlipPath + fileName;

            // Create a new PDF document
            // var renderer = new ChromePdfRender();
            var Renderer = new ChromePdfRenderer(); // Instantiates Chrome Renderer

            // Add content to the PDF page
            var html = $@"
                <h1>Order Invoice</h1>
                <p><strong>CustomerName:</strong> {order.CustomerName}</p>
                <p><strong>Order Date:</strong> {order.OrderDate}</p>
                <p><strong>Total:</strong> {order.Total:C}</p>
                <p><strong>Address:</strong> {order.AddressLine1}</p>
            ";

            var pdf = Renderer.RenderHtmlAsPdf(html);

            pdf.SaveAs(GeneratedFile);

        }
    }
}
