﻿using Dapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using EShop.Infrastructure.Consts;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace EShop.Infrastructure.Repositories
{
    public class CartRepository : ICartRepository
    {
        protected readonly IDbConnectionFactory _dbConnectionFactory;
        protected readonly IConfiguration _configuration;
        public CartRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
        }

        public async Task<int> AddCartItem(CartPurchaseItems purchaseRequest)
        {

            int cartId = 0;
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@CustomerId", purchaseRequest.CustomerId);

            DataTable itemsTable = new DataTable();
            itemsTable.Columns.Add("ProductId", typeof(int));
            itemsTable.Columns.Add("Quantity", typeof(int));
            itemsTable.Columns.Add("Discount", typeof(decimal));
            itemsTable.Columns.Add("IsLoyaltyMemberShip", typeof(bool));
            if (purchaseRequest.Items != null && purchaseRequest.Items.Count > 0)
            {
                foreach (var item in purchaseRequest.Items)
                {
                    bool IsMemberShip = false;
                    if (item.Type.ToLower() == MembershipType.Membership.ToString().ToLower())
                    {
                        IsMemberShip = true;
                    }

                    if (IsMemberShip)
                    {
                        itemsTable.Rows.Add(item.ProductId, item.Quantity, 20, IsMemberShip);
                    }
                    else
                    {
                        itemsTable.Rows.Add(item.ProductId, item.Quantity, item.Discount, IsMemberShip);
                    }
                }

                using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
                {
                    dbConnection.Open();
                    dynamicParameters.Add("@Items", itemsTable.AsTableValuedParameter("dbo.PurchaseItemTableType"));
                    cartId = await dbConnection.ExecuteScalarAsync<int>("InsertPurchaseRequest", dynamicParameters, commandType: CommandType.StoredProcedure);
                }
            }

            return cartId;
        }
        public async Task<List<CartItemDto>>  getCartItem(int CustomerID)
        {
            List<CartItemDto> cartItemList = new List<CartItemDto>();

            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {

                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@CustomerId", CustomerID);

                dbConnection.Open();

                // Define the stored procedure call using Dapper
                var parameters = new { Id = CustomerID };
                var purchaseCartItem = await dbConnection.QueryAsync<CartItemDto>("GetCarsDetailByCustomerId", dynamicParameters, commandType: CommandType.StoredProcedure);
                cartItemList = purchaseCartItem.ToList();
                return cartItemList;
            }

        }
    }
}
