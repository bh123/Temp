﻿using Dapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using Microsoft.Extensions.Configuration;
using OnlineLibraryShop.Core.Interfaces;
using System.Data;

namespace EShop.Infrastructure.Repositories
{
    public class MemberShipRepository : IMemberShipRepository
    {
        protected readonly IDbConnectionFactory _dbConnectionFactory;
        protected readonly IConfiguration _configuration;
        public MemberShipRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
        }
        public async Task AddUpdateMeberShipDetails(MemberShipDto input)
        {
            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                // Open the connection
                dbConnection.Open();

                // Call the stored procedure using Dapper
                await dbConnection.ExecuteAsync("InsertOrUpdateCustomerMembership", input, commandType: CommandType.StoredProcedure);
            }
        }
    }
}
