﻿namespace EShop.Core.Entities
{
    public class MemberShipDto
    {
        public string CustomerNumber { get; set; }
        public int OrderId { get; set; }
    }
}
