﻿using AutoMapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;
using OnlineLibraryShop.Core.Interfaces;

namespace EShop.Application.Command.Handler
{
    public class CheckoutCommandHandler : IRequestHandler<CheckoutCommand,int>
    {
        private readonly IShippingRepository _shippingRepository;
        private readonly ICartRepository _cartRepository;
        private readonly IOrderRepository _orderRepository;
        private readonly IMapper _mapper;

        public CheckoutCommandHandler(IShippingRepository shippingRepository, 
                                      ICartRepository cartRepository,
                                      IOrderRepository orderRepository, 
                                      IMapper mapper)
        {
            _shippingRepository = shippingRepository;
            _cartRepository = cartRepository;
            _orderRepository = orderRepository;
            _mapper = mapper;
        }

        public async Task<int> Handle(CheckoutCommand request, CancellationToken cancellationToken)
        {
            CartPurchaseItems cartPurchaseItems = new CartPurchaseItems();
            cartPurchaseItems.CustomerId = request.CustomerId;
            cartPurchaseItems.Items= request.Items;

            await _shippingRepository.InsertShippingData(request.Shipping);
            await _cartRepository.AddCartItem(cartPurchaseItems);
            var Id = await _orderRepository.CreatePurchaseOrder(new PurchaseRequestDto { CustomerId = request.CustomerId });
            return Id;
        }
    }
}
