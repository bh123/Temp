﻿using EShop.Application.Order;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop.Application.Command.Handler
{
    public class GetShippingAddressByIdQueryHandler : IRequestHandler<GetShippingAddressByIdQuery, List<Shipping>>
    {
        private readonly IShippingRepository _shippingRepository;
        public GetShippingAddressByIdQueryHandler(IShippingRepository shippingRepository)
        {
            _shippingRepository = shippingRepository;
        }

        public async Task<List<Shipping>> Handle(GetShippingAddressByIdQuery request, CancellationToken cancellationToken)
        {
            var result = await _shippingRepository.GetShippingData(request.CustomerId);
            return result;
        }
    }
}
