﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Core.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop.Application.Services
{
    public class ProductService : IProductService
    {
        private readonly IMediator _mediator;

        public ProductService(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<int> AddCartItems(CreateCartCommand createCartRequestCommand)
        {
            int OrderId = await _mediator.Send(createCartRequestCommand);
            return OrderId;
        }

        public async Task<List<Product>> GetProductList(GetCartQueryHandler getProductQuery)
        {
            var products=  await _mediator.Send(getProductQuery);
            return products;
        }
    }
}
