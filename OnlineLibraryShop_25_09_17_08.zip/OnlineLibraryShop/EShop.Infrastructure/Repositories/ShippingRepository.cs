﻿using Dapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace EShop.Infrastructure.Repositories
{
    public class ShippingRepository : IShippingRepository
    {
        protected readonly IDbConnectionFactory _dbConnectionFactory;
        protected readonly IConfiguration _configuration;
        public ShippingRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
        }

        public async Task<int> InsertShippingData(Shipping shipping)
        {
            int id = 0;
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@CustomerId", shipping.CustomerId);
            dynamicParameters.Add("@AddressLine1", shipping.AddressLine1);
            dynamicParameters.Add("@AddressLine2", shipping.AddressLine2);
            dynamicParameters.Add("@City", shipping.City);
            dynamicParameters.Add("@Country", shipping.Country);
            dynamicParameters.Add("@ZipCode", shipping.ZipCode);

            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                // Open the connection
                dbConnection.Open();

                // Call the stored procedure using Dapper
                id = await dbConnection.ExecuteScalarAsync<int>("InsertCustomerShippingAddress", dynamicParameters, commandType: CommandType.StoredProcedure);
            }
            return id;
        }

        public async Task<List<Shipping>> GetShippingData(int CustomerId)
        {
            List<Shipping> shippingList = new List<Shipping>();

            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@CustomerId", CustomerId);


            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                dbConnection.Open();

                IEnumerable<Shipping> shippingdata = await dbConnection.QueryAsync<Shipping>("GetCustomerShippingInfo", dynamicParameters, commandType: CommandType.StoredProcedure);
                shippingList = shippingdata.ToList();
                return shippingList;
            }
        }
    }
}
