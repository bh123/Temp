﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Controllers;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace OnlineLibraryShop_Test
{
    public class CartControllerTests
    {

        [Fact]
        public async Task Post_WithValidModel_ReturnsCreatedAtActionResult()
        {
            // Arrange
            var mockValidator = new Mock<IValidator<CreateCartCommand>>();
            mockValidator
                .Setup(validator => validator.ValidateAsync(It.IsAny<CreateCartCommand>(), default))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult());

            var mockCartService = new Mock<ICartService>();
            mockCartService
                .Setup(service => service.AddCartItems(It.IsAny<CreateCartCommand>()))
                .ReturnsAsync(1); // You should replace this with an actual ID

            var controller = new CartController(mockCartService.Object, mockValidator.Object);
            var cartRequestCommand = new CreateCartCommand(); // Create a valid command here

            // Act
            var result = await controller.Post(cartRequestCommand);

            // Assert
            var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result);
            Assert.Equal(nameof(CartController.Post), createdAtActionResult.ActionName);
        }

    }
}
