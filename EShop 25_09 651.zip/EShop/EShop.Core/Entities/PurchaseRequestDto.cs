namespace EShop.Core.Entities
{
    public class PurchaseRequestDto
    {
        public int CustomerId { get; set; }
       
    }

    

}