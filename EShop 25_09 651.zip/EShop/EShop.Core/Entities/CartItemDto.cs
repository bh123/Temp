﻿using System.ComponentModel.DataAnnotations;

namespace EShop.Core.Entities
{
    public class CartItemDto
    {
        public string Type { get; set; }
        public int Quantity { get; set; }
        [Required]
        public int ProductId { get; set; }
        //public int Discount { get; set; }
        //public int TotalAmount { get; set; }
    }
}
