﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Controllers;
using EShop.Core.Entities;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace OnlineLibraryShop_Test
{
    public class ShippingControllerTests
    {
        private readonly ShippingController _controller;
        private readonly Mock<IShippingService> _shippingServiceMock;
        private readonly Mock<IValidator<CreateShippingCommand>> _validatorMock;
        public ShippingControllerTests()
        {
            _shippingServiceMock = new Mock<IShippingService>();
            _validatorMock = new Mock<IValidator<CreateShippingCommand>>();
            _controller = new ShippingController(_shippingServiceMock.Object, _validatorMock.Object);
        }
        [Fact]
        public async Task Get_Should_Return_ShippingData()
        {
            // Arrange
            int customerId = 1;
            var shippingData = new Shipping(); // Replace with your actual shipping data object
            var validationResult = new FluentValidation.Results.ValidationResult();

            _validatorMock
    .Setup(validator => validator.ValidateAsync(It.IsAny<CreateShippingCommand>(), default))
    .ReturnsAsync(validationResult);


            // Act
            var result = await _controller.Get(customerId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var model = okResult.Value as Shipping; // Adjust the type based on your actual return type
            
            // Additional assertions on the model if needed
        }
    }

}
