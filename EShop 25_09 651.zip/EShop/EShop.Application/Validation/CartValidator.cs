﻿using EShop.Application.Command;
using EShop.Core.Entities;
using FluentValidation;

namespace EShop.Application.Validation
{
    public class CreateCartRequestCommandValidator : AbstractValidator<CreateCartCommand>
    {
        public CreateCartRequestCommandValidator()
        {
            RuleFor(request => request.CustomerId)
                .GreaterThan(0).WithMessage("Customer Id must be greater than 0");

            RuleFor(request => request.Items)
                .NotNull().WithMessage("Items cannot be null")
                .NotEmpty().WithMessage("Items cannot be empty");

            RuleForEach(request => request.Items)
                .SetValidator(new CartItemDtoValidator());
        }

        public class CartItemDtoValidator : AbstractValidator<CartItemDto>
        {
            public CartItemDtoValidator()
            {
                RuleFor(item => item.Type)
                    .NotEmpty().WithMessage("Type cannot be empty");

                RuleFor(item => item.Quantity)
                    .GreaterThan(0).WithMessage("Quantity must be greater than 0");

                RuleFor(item => item.ProductId)
                    .GreaterThan(0).WithMessage("ProductId must be greater than 0");

               
            }
        }
    }
}
