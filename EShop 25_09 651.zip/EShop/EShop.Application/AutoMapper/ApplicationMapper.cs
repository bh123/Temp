﻿using AutoMapper;
using EShop.Application.Command;
using EShop.Application.Order;
using EShop.Core.Entities;

namespace EShop.Application.AutoMapper
{
    public class ApplicationMapper : Profile
    {
        public ApplicationMapper()
        {
            CreateMap<PurchaseRequestDto, CreateOrderCommand>().ReverseMap();
            CreateMap<CreateCartCommand, CartPurchaseItems>().ReverseMap();
            CreateMap<CreateShippingCommand, Shipping>().ReverseMap();
            CreateMap<CreateShippingCommand, Shipping>().ReverseMap();

            
        }
    }
}
    

