﻿using EShop.Application.Command;

namespace EShop.Application.IServices
{
    public interface ICheckOutService
    {
        Task<int> Checkout(CheckoutCommand checkoutCommand);
    }
}
