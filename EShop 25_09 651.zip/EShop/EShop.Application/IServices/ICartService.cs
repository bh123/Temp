﻿using EShop.Application.Command;
using EShop.Core.Entities;

namespace EShop.Application.IServices
{
    public interface ICartService
    {
        Task<int> AddCartItems(CreateCartCommand createCartRequestCommand);

        Task<List<CartItemDto>> GetCartItem(GetCartItemQuery query);

    }
}
