﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Core.Entities;
using MediatR;
using System.Collections.Generic;

namespace EShop.Application.Services
{
    public class CartService : ICartService
    {
        private readonly IMediator _mediator;

        public CartService(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<int> AddCartItems(CreateCartCommand createCartRequestCommand)
        {
            int OrderId = await _mediator.Send(createCartRequestCommand);
            return OrderId;
        }

        public async Task<List<CartItemDto>> GetCartItem(GetCartItemQuery query)
        {
            List<CartItemDto> cartItems = await _mediator.Send(query);
            return cartItems;
        }
    }
}
