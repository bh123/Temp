﻿using AutoMapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;

namespace EShop.Application.Command.Handler
{
    public class CreateCartCommandHandler : IRequestHandler<CreateCartCommand, int>
    {
        private readonly ICartRepository _cartRepository;
         private readonly IMapper _mapper;
        public CreateCartCommandHandler(ICartRepository cartRepository, IMapper mapper)
        {
            _mapper = mapper;
            _cartRepository = cartRepository;
        }
        public async Task<int> Handle(CreateCartCommand command, CancellationToken cancellationToken)
        {
            var cartItemDto = _mapper.Map<CartPurchaseItems>(command);
            var id = await _cartRepository.AddCartItem(cartItemDto);
            return id;
        }
    }
}
