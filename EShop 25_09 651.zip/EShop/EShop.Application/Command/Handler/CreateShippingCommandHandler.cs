﻿using AutoMapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;

namespace EShop.Application.Command.Handler
{
    public class CreateShippingCommandHandler : IRequestHandler<CreateShippingCommand, int>
    {
        private readonly IShippingRepository _shippingRepository;
        private readonly IMapper _mapper;

        public CreateShippingCommandHandler(IShippingRepository shippingRepository, IMapper mapper)
        {
            _shippingRepository = shippingRepository;
            _mapper = mapper;
        }

        public Task<int> Handle(CreateShippingCommand request, CancellationToken cancellationToken)
        {
            var shipping = _mapper.Map<Shipping>(request);
            var result =_shippingRepository.InsertShippingData(shipping);
            return result;
        }
    }
}
