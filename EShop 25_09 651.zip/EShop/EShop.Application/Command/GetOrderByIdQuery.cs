﻿using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Order
{
    public class GetOrderByIdQuery : IRequest<OrderDto>
    {
        public int OrderId { get; set; }
    }
}
