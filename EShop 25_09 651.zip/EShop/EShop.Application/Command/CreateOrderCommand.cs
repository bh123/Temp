﻿using MediatR;
using OnlineLibraryShop.Core.Entities;

namespace EShop.Application.Order
{
    public class CreateOrderCommand : IRequest<int>
    {
        public int CustomerId { get; set; }
    }
}
