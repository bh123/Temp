﻿using FluentValidation;
using MediatR;
using OnlineLibraryShop.Application.AutoMapper;
using OnlineLibraryShop.Application.Command.Handler;
using OnlineLibraryShop.Application.CustomServices;
using OnlineLibraryShop.Application.IServices;
using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Application.Services;
using OnlineLibraryShop.Application.Validation;
using OnlineLibraryShop.Core.Interfaces;
using OnlineLibraryShop.Infrastructure.ConnectionFactory;
using OnlineLibraryShop.Infrastructure.Repositories;

namespace OnlineLibraryShop.Extensions
{
    public static class ApplicationServicesExtensions
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddScoped<IOrderService, OrderService>();
            services.AddScoped<IMemberShipService, MembershipService>();
            services.AddScoped<IOrderRepository, OrderRepository>();
            services.AddScoped<IMemberShipRepository, MemberShipRepository>();
            services.AddScoped<IGenerateSlip, GenerateSlip>();
            services.AddScoped<ITokenAuthService, TokenAuthService>();
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(CreateOrderCommand).Assembly));
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetOrderByIdQueryHandler).Assembly));
            services.AddAutoMapper(typeof(ApplicationMapper));
            services.AddValidatorsFromAssemblyContaining<OrderValidator>();
            services.AddScoped<IDbConnectionFactory, SqlDBConnectionFactory>();

            return services;
        }
    }
}
