﻿using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineLibraryShop.Application.IServices;
using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Application.Validation;
using OnlineLibraryShop.Core.Entities;

namespace OnlineLibraryShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchaseOrderController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly ILogger<PurchaseOrderController> _logger;
        private readonly IMemberShipService _memberShipService;
        private IValidator<CreateOrderCommand> _validator;

        public PurchaseOrderController(IOrderService orderService, ILogger<PurchaseOrderController> logger,
            IMemberShipService memberShipService, IValidator<CreateOrderCommand> validator)
        {
            _orderService = orderService;
            _logger = logger;
            _memberShipService = memberShipService;
            _validator = validator;
        }


        [Authorize]
        [HttpPost(Name = "CreatePurchaseOrder")]
        public async Task<ActionResult> Post([FromBody]CreateOrderCommand input)
        {
            var result = await _validator.ValidateAsync(input);

            if (!result.IsValid)
            {
                var errors = result.Errors.Select(e => e.ErrorMessage).ToList();
                return BadRequest(errors);
            }
            _logger.LogInformation("star processing for generate order");

            int OrderId = await _orderService.CreatePurchaseOrder(input);
            if (OrderId > 0)
            {
                MemberShipDto memberShipDto=new MemberShipDto();
                memberShipDto.OrderId = OrderId;
                memberShipDto.CustomerNumber=input.CustomerNumber;
                await _memberShipService.ActiveMemberShip(memberShipDto);

                await _orderService.GenerateSlipIfRequired(input, OrderId);
            }
            _logger.LogInformation("end processing for generate order");

            return CreatedAtAction(nameof(Post), new { id = OrderId }, new { GenerateOrderId = OrderId });



        }
    }
}
