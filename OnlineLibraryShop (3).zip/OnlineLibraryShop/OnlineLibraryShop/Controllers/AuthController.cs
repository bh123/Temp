﻿using Microsoft.AspNetCore.Mvc;
using OnlineLibraryShop.Application.IServices;
using OnlineLibraryShop.Core.Entities;

[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IConfiguration _configuration;
    private readonly ITokenAuthService _tokenAuthService;
    public AuthController(IConfiguration configuration, ITokenAuthService tokenAuthService)
    {
        _configuration = configuration;
        _tokenAuthService = tokenAuthService;
    }
    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginRequest loginReqest)
    {
        if (ModelState.IsValid)
        {
            var AllowedUserName = _configuration["Credentils:username"];
            var AllowedPassword = _configuration["Credentils:password"];

            if (loginReqest.UserName == AllowedUserName && loginReqest.Password == AllowedPassword)
            {
                var token = _tokenAuthService.GenerateJwtToken(loginReqest.UserName);
                return Ok(new { Token = token });
            }
            return Unauthorized();
        }
        else
        {
            return BadRequest("Please enter username and password");
        }
    }
}
