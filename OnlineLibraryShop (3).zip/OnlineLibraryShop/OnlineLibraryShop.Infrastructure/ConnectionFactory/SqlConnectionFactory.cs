﻿using Microsoft.Extensions.Configuration;
using OnlineLibraryShop.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineLibraryShop.Infrastructure.ConnectionFactory
{
    public class SqlDBConnectionFactory : IDbConnectionFactory
    {
        public IDbConnection CreateConnection(string ConnectionString)
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
