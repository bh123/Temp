﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OnlineLibraryShop.Core.Entities;
using OnlineLibraryShop.Core.Interfaces;
using OnlineLibraryShop.Infrastructure.Consts;
using System.Data;
using System.Data.SqlClient;
using static Dapper.SqlMapper;

namespace OnlineLibraryShop.Infrastructure.Repositories
{
    public class OrderRepository : IOrderRepository
    {

        private readonly IDbConnectionFactory _dbConnectionFactory;
        private readonly IConfiguration _configuration;
        public OrderRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
        }

        public async Task<int> CreatePurchaseOrder(PurchaseRequestDto purchaseRequest)
        {

            int orderid = 0;
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@CustomerNumber", purchaseRequest.CustomerNumber);

            DataTable itemsTable = new DataTable();
            itemsTable.Columns.Add("ProductType", typeof(string));
            itemsTable.Columns.Add("Quantity", typeof(int));
            itemsTable.Columns.Add("ProductName", typeof(string));
            itemsTable.Columns.Add("IsMemberShip", typeof(bool));

            foreach (var item in purchaseRequest.Items)
            {
                bool IsMemberShip = false;
                if (item.Type.ToLower() == MembershipType.Membership.ToString().ToLower())
                {
                    IsMemberShip = true;
                }
                if (item.Qty == 0)
                {
                    item.Qty = 1;
                }

                itemsTable.Rows.Add(item.Type, item.Qty, item.ProductName.Trim(), IsMemberShip);
            }

              using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                dbConnection.Open();
                dynamicParameters.Add("@Items", itemsTable.AsTableValuedParameter("dbo.PurchaseItemTableType"));
                orderid =  dbConnection.ExecuteScalar<int>("InsertPurchaseRequest", dynamicParameters, commandType: CommandType.StoredProcedure);
            }

            return orderid;
        }

        public async Task<OrderDto> GetPurchaseOrderDetail(int PurchaseOrderId)
        {
            OrderDto purchaseInvoice = new OrderDto();

            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                dbConnection.Open();

                // Define the stored procedure call using Dapper
                var parameters = new { Id = PurchaseOrderId };
                purchaseInvoice =  dbConnection.QueryFirstOrDefault<OrderDto>("GetOrdersById", parameters, commandType: CommandType.StoredProcedure);

                return purchaseInvoice;
            }
        }

    }
}
