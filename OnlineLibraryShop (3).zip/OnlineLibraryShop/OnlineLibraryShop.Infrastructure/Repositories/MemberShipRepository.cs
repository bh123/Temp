﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OnlineLibraryShop.Core.Entities;
using OnlineLibraryShop.Core.Interfaces;
using System.Data;
using System.Data.SqlClient;

namespace OnlineLibraryShop.Infrastructure.Repositories
{
    public class MemberShipRepository : IMemberShipRepository
    {
        protected readonly IDbConnectionFactory _dbConnectionFactory;
        protected readonly IConfiguration _configuration;
        public MemberShipRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
        }
        public async Task AddUpdateMeberShipDetails(MemberShipDto input)
        {
            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                // Open the connection
                dbConnection.Open();

                // Call the stored procedure using Dapper
                await dbConnection.ExecuteAsync("InsertOrUpdateCustomerMembership", input, commandType: CommandType.StoredProcedure);
            }
        }
    }
}
