using OnlineLibraryShop.Core.Entities;
using System.Data;

namespace OnlineLibraryShop.Core.Interfaces
{
    public interface IOrderRepository
    {
        Task<int> CreatePurchaseOrder(PurchaseRequestDto purchaseRequest);

       Task<OrderDto> GetPurchaseOrderDetail(int PurchaseId);

          


    }
}
