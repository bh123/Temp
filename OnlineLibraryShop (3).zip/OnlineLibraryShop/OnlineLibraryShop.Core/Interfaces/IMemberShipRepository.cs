﻿using OnlineLibraryShop.Core.Entities;

namespace OnlineLibraryShop.Core.Interfaces
{
    public interface IMemberShipRepository
    {
        Task AddUpdateMeberShipDetails(MemberShipDto input);
    }
}
