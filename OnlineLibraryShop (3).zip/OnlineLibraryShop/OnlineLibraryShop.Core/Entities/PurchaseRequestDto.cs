using System.ComponentModel.DataAnnotations;
namespace OnlineLibraryShop.Core.Entities
{
    public class PurchaseRequestDto
    {
        [Required]
        public string CustomerNumber { get; set; }
        public List<PurchaseItemDto> Items { get; set; }
    }

    public class PurchaseRequestDto1
    {
        [Required]
        public string CustomerNumber { get; set; }
        public List<PurchaseItemDto> Items { get; set; }
    }

}