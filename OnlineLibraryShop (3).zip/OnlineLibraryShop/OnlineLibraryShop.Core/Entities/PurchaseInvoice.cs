﻿namespace OnlineLibraryShop.Core.Entities
{
    public class PurchaseInvoice
    {
        public string CustomerName { get; set; }
        public List<PurchaseItemDto> PurchaseItems { get; set; }
        public DateTime TxnDate { get; set; }
        public Decimal TotalAmount { get; set; }
        public string Address { get; set; }
    }
}
