﻿namespace OnlineLibraryShop.Core.Entities
{
    public class CustomResponseDTo
    {
        public string SucessMesssage { get; set; }
        public string StatusCode { get; set; }

        public string ErrorMessage { get; set; }

        public string ValidationMessage { get; set; }

    }
}
