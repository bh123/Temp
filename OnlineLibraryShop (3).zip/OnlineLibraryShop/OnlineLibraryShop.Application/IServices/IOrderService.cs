﻿using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Core.Entities;

namespace OnlineLibraryShop.Application.IServices
{
    public interface IOrderService
    {
        Task<int> CreatePurchaseOrder(CreateOrderCommand purchaseRequestDto);


        Task GenerateSlipIfRequired(CreateOrderCommand purchaseRequestDto, int OrderId);

    }
}
