﻿using MediatR;
using OnlineLibraryShop.Application.Command;
using OnlineLibraryShop.Application.IServices;
using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineLibraryShop.Application.Services
{
    public class MembershipService : IMemberShipService
    {
        private readonly IMediator _mediator;


        public MembershipService(IMediator mediator)
        {
            _mediator = mediator;
        }
        public async Task ActiveMemberShip(MemberShipDto request)
        {
            await _mediator.Send(new CreateMemberShipCommand { CustomerNumber = request.CustomerNumber, OrderId = request.OrderId });
        }
       
    }
}
