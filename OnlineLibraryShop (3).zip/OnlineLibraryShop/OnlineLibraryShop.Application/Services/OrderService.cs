﻿using AutoMapper;
using MediatR;
using OnlineLibraryShop.Application.AutoMapper;
using OnlineLibraryShop.Application.IServices;
using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Application.Validation;
using OnlineLibraryShop.Core.Entities;
using OnlineLibraryShop.Infrastructure.Consts;

namespace OnlineLibraryShop.Application.CustomServices
{
    public class OrderService : IOrderService
    {
        private readonly IMediator _mediator;

        private readonly IGenerateSlip _generateSlip;

        public OrderService(IMediator mediator, IGenerateSlip generateSlip)
        {
            _mediator = mediator;
            _generateSlip = generateSlip;
        }

        public async Task<int> CreatePurchaseOrder(CreateOrderCommand createOrderCommand)
        {
            int OrderId = await _mediator.Send(createOrderCommand);
            return OrderId;
        }

        public async Task GenerateSlipIfRequired(CreateOrderCommand purchaseRequestDto,int OrderId)
        {
            if (purchaseRequestDto.Items.Any(x => x.Type.ToLower() == MembershipType.NonMembership.ToString().ToLower()))
            {
                OrderDto orderDto = new OrderDto();
                orderDto = await _mediator.Send(new GetOrderByIdQuery { OrderId = OrderId });
                _generateSlip.GeneratePdf(orderDto);
            }
        }
    }
}
