﻿using AutoMapper;
using OnlineLibraryShop.Application.Command;
using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Core.Entities;

namespace OnlineLibraryShop.Application.AutoMapper
{
    public class ApplicationMapper : Profile
    {
        public ApplicationMapper()
        {
            CreateMap<PurchaseRequestDto, CreateOrderCommand>().ReverseMap();
            CreateMap<MemberShipDto, CreateMemberShipCommand>().ReverseMap();

        }
    }
}
    

