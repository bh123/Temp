﻿using OnlineLibraryShop.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineLibraryShop.Application.Validation
{
    public interface IGenerateSlip
    {
        void GeneratePdf(OrderDto order);

    }
}
