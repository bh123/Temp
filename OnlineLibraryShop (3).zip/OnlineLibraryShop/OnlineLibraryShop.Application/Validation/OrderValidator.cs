﻿using FluentValidation;
using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Core.Entities;
using OnlineLibraryShop.Infrastructure.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineLibraryShop.Application.Validation
{
    public class OrderValidator : AbstractValidator<CreateOrderCommand>
    {
        public OrderValidator()
        {
            RuleFor(order => order.CustomerNumber)
            .NotEmpty().WithMessage("Customer Number is required.");

            RuleForEach(order => order.Items)
           .SetValidator(new OrderItemValidator());
        }


        public class OrderItemValidator : AbstractValidator<PurchaseItemDto>
        {
            public OrderItemValidator()
            {
                RuleFor(item => item.ProductName)
                    .NotEmpty().WithMessage("Product name is required.");

                RuleFor(item => item.Qty)
                    .GreaterThan(0).WithMessage("Quantity must be greater than zero.");

                RuleFor(item => item.Type)
                .Must(BeValidType)
                .WithMessage("Type must be 'membership' or 'nonmembership'");

            }
            private bool BeValidType(string type)
            {
                return type.ToLower() == MembershipType.Membership.ToString().ToLower() || type.ToLower() == MembershipType.NonMembership.ToString().ToLower();
            }
        }


    }


}
