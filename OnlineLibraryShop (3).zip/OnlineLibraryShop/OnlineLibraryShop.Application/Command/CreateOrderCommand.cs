﻿using MediatR;
using OnlineLibraryShop.Core.Entities;

namespace OnlineLibraryShop.Application.Order
{
    public class CreateOrderCommand : IRequest<int>
    {
        public string CustomerNumber { get; set; }
        public List<PurchaseItemDto> Items { get; set; }

    }
}
