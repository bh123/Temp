﻿using MediatR;
using OnlineLibraryShop.Core.Entities;

namespace OnlineLibraryShop.Application.Order
{
    public class GetOrderByIdQuery : IRequest<OrderDto>
    {
        public int OrderId { get; set; }
    }
}
