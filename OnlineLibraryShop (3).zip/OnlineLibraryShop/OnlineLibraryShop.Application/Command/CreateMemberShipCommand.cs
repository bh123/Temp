﻿using MediatR;

namespace OnlineLibraryShop.Application.Command
{
    public class CreateMemberShipCommand : IRequest 
    {
        public string CustomerNumber { get; set; }
        public int OrderId { get; set; }

    }
}
