﻿using MediatR;
using Moq;
using OnlineLibraryShop.Application.CustomServices;
using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Application.Validation;
using OnlineLibraryShop.Core.Entities;
using Xunit;

namespace OnlineLibrary_Test
{
    public class PurchaseOrderServiceTests
    {
        [Fact]
        public async Task CreatePurchaseOrder_ShouldReturnOrderId()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var generateSlipMock = new Mock<IGenerateSlip>();
            var orderService = new OrderService(mediatorMock.Object, generateSlipMock.Object);

            var createOrderCommand = new CreateOrderCommand();

            int expectedOrderId = 1;
            mediatorMock.Setup(m => m.Send(createOrderCommand, CancellationToken.None))
                .ReturnsAsync(expectedOrderId);

            // Act
            int result = await orderService.CreatePurchaseOrder(createOrderCommand);

            // Assert
            Assert.Equal(expectedOrderId, result);
        }

        [Fact]
        public async Task GenerateSlipIfRequired_ShouldGenerateSlipForNonMembershipItems()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var generateSlipMock = new Mock<IGenerateSlip>();
            var orderService = new OrderService(mediatorMock.Object, generateSlipMock.Object);

            int orderId = 1;

            var purchaseRequestDto = new CreateOrderCommand
            {
                Items = new List<PurchaseItemDto>
            {
                new PurchaseItemDto { Type = "NonMembership" },
                new PurchaseItemDto { Type = "Membership" },
            }
            };

            mediatorMock.Setup(m => m.Send(It.IsAny<GetOrderByIdQuery>(), CancellationToken.None))
                .ReturnsAsync(new OrderDto());

            // Act
            await orderService.GenerateSlipIfRequired(purchaseRequestDto, orderId);

            // Assert
            generateSlipMock.Verify(g => g.GeneratePdf(It.IsAny<OrderDto>()), Times.Once());
        }

        [Fact]
        public async Task GenerateSlipIfRequired_ShouldNotGenerateSlipForMembershipItems()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var generateSlipMock = new Mock<IGenerateSlip>();
            var orderService = new OrderService(mediatorMock.Object, generateSlipMock.Object);

            int orderId = 1;

            var purchaseRequestDto = new CreateOrderCommand
            {
                Items = new List<PurchaseItemDto>
            {
                new PurchaseItemDto { Type = "Membership" },
            }
            };

            mediatorMock.Setup(m => m.Send(It.IsAny<GetOrderByIdQuery>(), CancellationToken.None))
                .ReturnsAsync(new OrderDto());

            // Act
            await orderService.GenerateSlipIfRequired(purchaseRequestDto, orderId);

            // Assert
            generateSlipMock.Verify(g => g.GeneratePdf(It.IsAny<OrderDto>()), Times.Never());
        }
    }

}