﻿using AutoMapper;
using MediatR;
using Moq;
using OnlineLibraryShop.Application.Command;
using OnlineLibraryShop.Application.Command.Handler;
using OnlineLibraryShop.Core.Entities;
using OnlineLibraryShop.Core.Interfaces;
using System.Threading;
using Xunit;

public class CreateMemberShipCommandHandlerTests
{
    [Fact]
    public async Task Handle_ValidCommand_CallsRepositoryAddUpdateMethod()
    {
        // Arrange
        var command = new CreateMemberShipCommand(); // Create a test command
        command.CustomerNumber = "test123";
        command.OrderId = 1;
       var memberShipDto = new MemberShipDto(); // Create a test DTO

        var memberShipRepositoryMock = new Mock<IMemberShipRepository>();
        var mapperMock = new Mock<IMapper>();

        mapperMock.Setup(m => m.Map<MemberShipDto>(command)).Returns(memberShipDto);

        var handler = new CreateMemberShipCommandHandler(memberShipRepositoryMock.Object, mapperMock.Object);

        // Act
        await handler.Handle(command, CancellationToken.None);

        // Assert
        memberShipRepositoryMock.Verify(repo => repo.AddUpdateMeberShipDetails(memberShipDto), Times.Once);
    }
}
