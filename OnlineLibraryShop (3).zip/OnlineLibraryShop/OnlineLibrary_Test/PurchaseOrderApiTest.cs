﻿using System;
using System.Threading.Tasks;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using OnlineLibraryShop.Application.IServices;
using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Controllers;
using OnlineLibraryShop.Core.Entities;
using Xunit;

namespace OnlineLibraryShop_Test
{
    public class PurchaseOrderTest
    {

        [Fact]
        public async Task Post_ValidInput_ReturnsCreatedAtAction()
        {
            // Arrange
            var orderServiceMock = new Mock<IOrderService>();
            var loggerMock = new Mock<ILogger<PurchaseOrderController>>();
            var memberShipServiceMock = new Mock<IMemberShipService>();
            var validatorMock = new Mock<IValidator<CreateOrderCommand>>();

            var controller = new PurchaseOrderController(
                orderServiceMock.Object,
                loggerMock.Object,
                memberShipServiceMock.Object,
                validatorMock.Object
            );

            var input = new CreateOrderCommand
            {
                // Initialize with valid data for testing
                CustomerNumber = "customer1",
                Items = new List<PurchaseItemDto>()
                {
                    new PurchaseItemDto{ ProductName="ProductA", Qty=1,Type="membership"}
                }
            };


            validatorMock.Setup(v => v.ValidateAsync(input, default))
    .ReturnsAsync(new FluentValidation.Results.ValidationResult());

            orderServiceMock.Setup(o => o.CreatePurchaseOrder(input))
                .ReturnsAsync(1);

            memberShipServiceMock.Setup(m => m.ActiveMemberShip(It.IsAny<MemberShipDto>()))
                .Returns(Task.CompletedTask);

            // Act
            var result = await controller.Post(input);

            // Assert
            var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result);
            Assert.Equal(nameof(PurchaseOrderController.Post), createdAtActionResult.ActionName);
            Assert.Equal(1, createdAtActionResult.RouteValues["id"]);
        }


        [Fact]
        public async Task Post_InvalidInput_ReturnsBadRequest()
        {
            // Arrange
            var orderServiceMock = new Mock<IOrderService>();
            var loggerMock = new Mock<ILogger<PurchaseOrderController>>();
            var memberShipServiceMock = new Mock<IMemberShipService>();
            var validatorMock = new Mock<IValidator<CreateOrderCommand>>();

            var controller = new PurchaseOrderController(
                orderServiceMock.Object,
                loggerMock.Object,
                memberShipServiceMock.Object,
                validatorMock.Object
            );

            var input = new CreateOrderCommand
            {
                // Initialize with invalid data for testing
                CustomerNumber = "testcustomer1",
                Items = new List<PurchaseItemDto> { new PurchaseItemDto
               {
                ProductName="Test Product",
                Qty=1,
                Type="membership"
            } }
            };

            var validationResult = new FluentValidation.Results.ValidationResult();
            validationResult.Errors.Add(new FluentValidation.Results.ValidationFailure("Property", "Error message"));

            validatorMock.Setup(v => v.ValidateAsync(input, default))
                .ReturnsAsync(validationResult);

            // Act
            var result = await controller.Post(input);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<List<string>>(badRequestResult.Value);
            Assert.Contains("Error message", (List<string>)badRequestResult.Value);
        }



    }
}
