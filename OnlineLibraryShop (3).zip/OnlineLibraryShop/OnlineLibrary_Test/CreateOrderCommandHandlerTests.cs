﻿using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Moq;
using OnlineLibraryShop.Application.Command.Handler;
using OnlineLibraryShop.Application.Order;
using OnlineLibraryShop.Core.Entities;
using OnlineLibraryShop.Core.Interfaces;
using Xunit;

public class CreateOrderCommandHandlerTests
{
    [Fact]
    public async Task Handle_ValidCommand_ReturnsOrderId()
    {
        // Arrange
        var orderRepositoryMock = new Mock<IOrderRepository>();
        var mapperMock = new Mock<IMapper>();

        var createOrderCommand = new CreateOrderCommand
        {
            CustomerNumber = "test1",
            Items = new List<PurchaseItemDto> { new PurchaseItemDto
            {
                ProductName="Test Product",
                Qty=1,
                Type="membership"
            } }
        };

        var purchaseRequestDto = new PurchaseRequestDto
        {
            CustomerNumber = "test1",
            Items = new List<PurchaseItemDto> { new PurchaseItemDto
            {
                ProductName="Test Product",
                Qty=1,
                Type="membership"
            } }
        };

        var orderId = 1;  

        orderRepositoryMock.Setup(repo => repo.CreatePurchaseOrder(It.IsAny<PurchaseRequestDto>()))
                          .ReturnsAsync(orderId);

        mapperMock.Setup(mapper => mapper.Map<PurchaseRequestDto>(createOrderCommand))
                  .Returns(purchaseRequestDto);

        var handler = new CreateOrderCommandHandler(orderRepositoryMock.Object, mapperMock.Object);

        // Act
        var result = await handler.Handle(createOrderCommand, CancellationToken.None);

        // Assert
        Assert.Equal(orderId, result);
    }

    
}
