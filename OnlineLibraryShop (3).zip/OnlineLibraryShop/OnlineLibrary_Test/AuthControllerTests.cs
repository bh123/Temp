﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using OnlineLibraryShop.Application.IServices;
using OnlineLibraryShop.Core.Entities;
using Xunit;


namespace OnlineLibraryShop_Test
{

    public class AuthControllerTests
    {
        [Fact]
        public void Login_ValidCredentials_ReturnsOkResultWithToken()
        {
            // Arrange
            var configurationMock = new Mock<IConfiguration>();
            configurationMock.Setup(c => c["Credentils:username"]).Returns("admin");
            configurationMock.Setup(c => c["Credentils:password"]).Returns("123qwe");

            var tokenAuthServiceMock = new Mock<ITokenAuthService>();
            tokenAuthServiceMock.Setup(t => t.GenerateJwtToken("admin")).Returns("fakeToken");

            var controller = new AuthController(configurationMock.Object, tokenAuthServiceMock.Object);

            var loginRequest = new LoginRequest();
            loginRequest.UserName = "admin";
            loginRequest.Password = "123qwe";

            // Act
            var result = controller.Login(loginRequest) as OkObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(200, result.StatusCode);

            Assert.True(result.Value.ToString().Contains("fakeToken"));
        }


        [Fact]
        public void Login_InvalidCredentials_ReturnsUnauthorized()
        {
            var configurationMock = new Mock<IConfiguration>();
            var tokenAuthServiceMock = new Mock<ITokenAuthService>();

            var controller = new AuthController(configurationMock.Object, tokenAuthServiceMock.Object);
            controller.ModelState.AddModelError("Key", "Error Message");

            var loginRequest = new LoginRequest();

            // Act
            var result = controller.Login(loginRequest) as BadRequestObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(400, result.StatusCode);
            Assert.Equal("Please enter username and password", result.Value);
        }
    }
}


