﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineLibraryShop_Test
{
    using System;
    using System.Threading;
    using System.Threading.Tasks;
    using Moq;
    using OnlineLibraryShop.Application.Command.Handler;
    using OnlineLibraryShop.Application.Order;
    using OnlineLibraryShop.Core.Entities;
    using OnlineLibraryShop.Core.Interfaces;
    using Xunit;

    public class GetOrderByIdQueryHandlerTests
    {
        [Fact]
        public async Task Handle_ValidOrderId_ReturnsOrderDto()
        {
            // Arrange
            int orderId = 1;
            var orderRepositoryMock = new Mock<IOrderRepository>();
            var expectedOrder = new OrderDto { /* Populate with expected data */ };
            orderRepositoryMock.Setup(repo => repo.GetPurchaseOrderDetail(orderId))
                              .ReturnsAsync(expectedOrder);

            var handler = new GetOrderByIdQueryHandler(orderRepositoryMock.Object);
            var query = new GetOrderByIdQuery();
            query.OrderId = 1;

            // Act
            var result = await handler.Handle(query, CancellationToken.None);

            // Assert
            Assert.NotNull(result);
            // Add more specific assertions based on your requirements
        }

        [Fact]
        public async Task Handle_InvalidOrderId_ReturnsNull()
        {
            // Arrange
            int orderId = 1; // Provide an invalid orderId
            var orderRepositoryMock = new Mock<IOrderRepository>();
            orderRepositoryMock.Setup(repo => repo.GetPurchaseOrderDetail(orderId))
                              .ReturnsAsync((OrderDto)null);

            var handler = new GetOrderByIdQueryHandler(orderRepositoryMock.Object);
            var query = new GetOrderByIdQuery();
            query.OrderId = 1;

            // Act
            var result = await handler.Handle(query, CancellationToken.None);

            // Assert
            Assert.Null(result);
        }
    }

}
