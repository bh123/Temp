﻿using Dapper;
using global::OnlineLibraryShop.Infrastructure.Repositories;
using Microsoft.Extensions.Configuration;
using Moq;
using Moq.Dapper;
using OnlineLibraryShop.Core.Entities;
using OnlineLibraryShop.Core.Interfaces;
using System.Data;
using System.Data.Common;
using Xunit;

namespace OnlineLibraryShop.Tests
{
    public class OrderRepositoryTests
    {
 
        [Fact]
        public async Task CreatePurchaseOrder_Should_CreateOrder()
        {
            var mockConfSection = new Mock<IConfigurationSection>();
            mockConfSection.SetupGet(m => m[It.Is<string>(s => s == "ConnectionStrings")]).Returns("abc");

            var mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(a => a.GetSection(It.Is<string>(s => s == "ConnectionStrings"))).Returns(mockConfSection.Object);

            var mockConnection = new Mock<IDbConnection>();

            var mockdbConnectionFactory = new Mock<IDbConnectionFactory>();
            mockdbConnectionFactory.Setup(factory => factory.CreateConnection(It.IsAny<string>())).Returns(mockConnection.Object);

            mockConnection.SetupDapper(c => c.ExecuteScalar(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<IDbTransaction>(), It.IsAny<int?>(), It.IsAny<CommandType?>()))
                     .Returns(1);

            var _orderRepository = new OrderRepository(mockdbConnectionFactory.Object, mockConfiguration.Object);

            // Arrange
            var purchaseRequest = new PurchaseRequestDto
            {
                CustomerNumber = "123",
                Items = new List<PurchaseItemDto>
                    {

                        new PurchaseItemDto { Type = "Book", Qty = 2, ProductName = "Book1" },
                        new PurchaseItemDto { Type = " ", Qty = 1, ProductName = "Membership1" },
                    }
            };

            // Act
            var orderId = await _orderRepository.CreatePurchaseOrder(purchaseRequest);

            // Assert
            Assert.True(orderId > 0);
        }



        [Fact]
        public async Task GetOrderById_Should_Work()
        {
            OrderDto orderDto = new OrderDto();
            orderDto.Id = 1;

            var mockConfSection = new Mock<IConfigurationSection>();
            mockConfSection.SetupGet(m => m[It.Is<string>(s => s == "ConnectionStrings")]).Returns("abc");

            var mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(a => a.GetSection(It.Is<string>(s => s == "ConnectionStrings"))).Returns(mockConfSection.Object);
            
            var mockConnection = new Mock<IDbConnection>();

            var mockdbConnectionFactory = new Mock<IDbConnectionFactory>();
            mockdbConnectionFactory.Setup(factory => factory.CreateConnection(It.IsAny<string>())).Returns(mockConnection.Object);

            mockConnection.SetupDapper(c => c.QueryFirstOrDefault(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<IDbTransaction>(), It.IsAny<int?>(), It.IsAny<CommandType?>()))
                     .Returns(orderDto);

            var _orderRepository = new OrderRepository(mockdbConnectionFactory.Object, mockConfiguration.Object);
             
            // Act
            var result = await _orderRepository.GetPurchaseOrderDetail(It.IsAny<int>());

            Assert.Null(result);
        }


    }
}

 