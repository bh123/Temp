﻿using AutoMapper;
using EShop.Application.Command;
using EShop.Application.Dto;
using EShop.Application.IServices;
using EShop.Application.Order;
using EShop.Application.Services;
using EShop.Application.Validation;
using EShop.Core.Entities;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using System.Net;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace OnlineLibraryShop.Application.CustomServices
{
    public class OrderService : IOrderService
    {
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        private readonly IGenerateSlip _generateSlip;

        public OrderService(IMediator mediator, IGenerateSlip generateSlip, IMapper mapper)
        {
            _mediator = mediator;
            _generateSlip = generateSlip;
            _mapper = mapper;
        }

        public async Task<ApiResponse<int>> CreatePurchaseOrder(Order order)
        {
            OrderEntity orderEntity = new OrderEntity();
            orderEntity = _mapper.Map<OrderEntity>(order);
            CreateOrderCommand createOrderCommand = new CreateOrderCommand() { payload = orderEntity };
            var orderid = await _mediator.Send(createOrderCommand);
            if (orderid > 0)
            {
                return new ApiResponse<int>
                {
                    Data = orderid,
                    HasError = false,
                    Error = string.Empty,
                    StatusCode = (int)HttpStatusCode.OK
                };
            }
            else
            {
                return new ApiResponse<int>
                {
                    Data = orderid,
                    HasError = false,
                    Error = string.Empty,
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<bool> GenerateSlipIfRequired(Order order)
        {
            ShippingSlipEntity shipping = new ShippingSlipEntity();

            var orderResponse = await _mediator.Send(new GetOrderByIdQuery { OrderId = order.OrderId });
            var shippingResponse = await _mediator.Send(new GetShippingAddressByIdQuery { CustomerId = order.CustomerId });

            shipping.orderDetails = orderResponse;
            //shipping.shipping = shippingResponse.Data;
            if (shipping.orderDetails.Count > 0)
            {
                return _generateSlip.GeneratePdf(shipping);
            }
            return false;

        }

        public async Task<ApiResponse<List<string>>> ValidateOrderData(Order command)
        {
            List<string> errorList = new List<string>();
            var customer = await _mediator.Send(new GetCustomerByIdQuery { CustomerId = command.CustomerId });

            if (customer == null)
            {
                errorList.Add("CustomerId is not valid");
            }

            var cartItem = await _mediator.Send(new GetCartItemQuery { CustomerId = command.CustomerId });
            if (cartItem.Count == 0)
            {
                errorList.Add("Cart should not be empty while place order");

            }
            if (errorList.Count > 0)
            {
                return new ApiResponse<List<string>>
                {
                    StatusCode = (int)HttpStatusCode.NotFound,
                    Error = "invalid data",
                    HasError = true,
                    Data = errorList
                };
            }
            else
            {
                return new ApiResponse<List<string>>
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Error = string.Empty,
                    HasError = false,
                    Data = errorList
                };
            }
        }
    }
}
