﻿using EShop.Application.Command;
using EShop.Application.Dto;
using EShop.Application.IServices;
using EShop.Application.Order;
using EShop.Core.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop.Application.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly IMediator _mediator;

        public CustomerService(IMediator mediator)
        {
            _mediator = mediator;
        }
        public async Task<ApiResponse<Customer>> GetCustomerById(Customer customer)
        {
            Customer customer1 = new Customer();
            var Customer = await _mediator.Send(new GetCustomerByIdQuery { CustomerId = customer.CustomerId });
            return new ApiResponse<Customer>()
            {
                Data = customer1
            };
        }


    }
}
