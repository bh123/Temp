﻿using EShop.Application.Command;
using EShop.Application.Services;
using EShop.Core.Entities;
using MediatR;
using Moq;
using Xunit;

namespace OnlineLibraryShop_Test
{
    public class ProductServiceTests
    {
        [Fact]
        public async Task AddCartItems_ReturnsOrderId()
        {
            //// Arrange
            //var mediatorMock = new Mock<IMediator>();
            //mediatorMock
            //    .Setup(m => m.Send(It.IsAny<CreateCartCommand>(), default))
            //    .ReturnsAsync(123); // Simulate the mediator returning an order ID

            //var productService = new ProductService(mediatorMock.Object);
            //var createCartCommand = new CreateCartCommand();

            //// Act
            //int orderId = await productService.AddCartItems(createCartCommand);

            //// Assert
            //Assert.Equal(123, orderId);
        }

        [Fact]
        public async Task GetProductList_ReturnsProductList()
        {
            //// Arrange
            //var mediatorMock = new Mock<IMediator>();
            //mediatorMock
            //    .Setup(m => m.Send(It.IsAny<GetCartQueryHandler>(), default))
            //    .ReturnsAsync(new List<Product>
            //    {
            //    new Product { Name = "Product 1" },
            //    new Product {  Name = "Product 2" }
            //    }); // Simulate the mediator returning a list of products

            //var productService = new ProductService(mediatorMock.Object);
            //var getProductQuery = new GetCartQueryHandler();

            //// Act
            //var products = await productService.GetProductList(getProductQuery);

            //// Assert
            //Assert.NotNull(products);
            //Assert.Equal(2, products.Count);
        }
    }

   
}
