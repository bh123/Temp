﻿using Dapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using EShop.Infrastructure.DataModel;
using Microsoft.Extensions.Configuration;
using OnlineLibraryShop.Core.Interfaces;
using System.Data;
using static Dapper.SqlMapper;

namespace EShop.Infrastructure.Repositories
{
    public class OrderRepository : IOrderRepository
    {

        private readonly IDbConnectionFactory _dbConnectionFactory;
        private readonly IConfiguration _configuration;
        public OrderRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
        }

        public async Task<int> CreatePurchaseOrder(OrderEntity purchaseRequest)
        {

            int orderid = 0;
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@CustomerId", purchaseRequest.CustomerId);
            dynamicParameters.Add("@ShipId", purchaseRequest.ShipId);
            dynamicParameters.Add("@IncludeLoyaltyMembership", purchaseRequest.IncludeLoyaltyMembership);

            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                // Open the connection
                dbConnection.Open();

                // Call the stored procedure using Dapper
                orderid = await dbConnection.ExecuteScalarAsync<int>("CreatePurchaseOrder", dynamicParameters, commandType: CommandType.StoredProcedure);
            }

            return orderid;
        }

        public async Task<List<OrderEntity>> GetPurchaseOrderDetail(int PurchaseOrderId)
        {
            List<OrderEntity> purchaseOrderList = new List<OrderEntity>();
            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                dbConnection.Open();

                // Define the stored procedure call using Dapper
                var parameters = new { Id = PurchaseOrderId };
                var result = await dbConnection.QueryAsync<OrderDataModel>("GetOrdersById", parameters, commandType: CommandType.StoredProcedure);
                //purchaseOrderList = result.ToList();
                //convert data model to entity and retunr 
                return purchaseOrderList;
            }
        }
 
    }
}
