﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Application.Order;
using EShop.Core.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop.Application.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly IMediator _mediator;

        public CustomerService(IMediator mediator)
        {
            _mediator = mediator;
        }
        public async Task<Customer> GetCustomerById(GetCustomerByIdQuery request)
        {
            var Customer = await _mediator.Send(request);
            return Customer;
        }

        
    }
}
