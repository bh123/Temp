﻿using EShop.Application.Command;
using EShop.Core.Entities;

namespace EShop.Application.IServices
{
    public interface IShippingService
    {
      Task<int> InsertShippingAddress(CreateShippingCommand shipping);

        Task<List<Shipping>> GetShippingData(GetShippingAddressByIdQuery query);

    }
}
