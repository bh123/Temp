﻿using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Order
{
    public class GetOrderByIdQuery : IRequest<List<GetOrderDetail>>
    {
        public int OrderId { get; set; }
    }
}
