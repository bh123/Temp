using EShop.Core.Entities;
using OnlineLibraryShop.Core.Entities;
using System.Data;

namespace OnlineLibraryShop.Core.Interfaces
{
    public interface IOrderRepository
    {
        Task<int> CreatePurchaseOrder(PurchaseRequestDto purchaseRequest);

        Task<List<GetOrderDetail>> GetPurchaseOrderDetail(int PurchaseOrderId);

    }
}
