﻿using Dapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using Microsoft.Extensions.Configuration;
using OnlineLibraryShop.Core.Interfaces;
using System.Collections.Generic;
using System.Data;
using static Dapper.SqlMapper;

namespace EShop.Infrastructure.Repositories
{
    public class OrderRepository : IOrderRepository
    {

        private readonly IDbConnectionFactory _dbConnectionFactory;
        private readonly IConfiguration _configuration;
        public OrderRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
        }

        public async Task<int> CreatePurchaseOrder(PurchaseRequestDto purchaseRequest)
        {

            int orderid = 0;
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@CustomerId", purchaseRequest.CustomerId);
            dynamicParameters.Add("@ShipId", purchaseRequest.ShipId);
            dynamicParameters.Add("@IncludeLoyaltyMembership", purchaseRequest.IncludeLoyaltyMembership);

            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                // Open the connection
                dbConnection.Open();

                // Call the stored procedure using Dapper
                orderid = await dbConnection.ExecuteScalarAsync<int>("CreatePurchaseOrder", dynamicParameters, commandType: CommandType.StoredProcedure);
            }

            return orderid;
        }

        public async Task<List<GetOrderDetail>> GetPurchaseOrderDetail(int PurchaseOrderId)
        {
            List<GetOrderDetail> purchaseOrderList = new List<GetOrderDetail>();

            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                dbConnection.Open();

                // Define the stored procedure call using Dapper
                var parameters = new { Id = PurchaseOrderId };
                var result = await dbConnection.QueryAsync<GetOrderDetail>("GetOrdersById", parameters, commandType: CommandType.StoredProcedure);
                purchaseOrderList = result.ToList();
                return purchaseOrderList;
            }
        }

    }
}
