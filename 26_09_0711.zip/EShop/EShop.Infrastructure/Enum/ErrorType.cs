﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop.Infrastructure.Enum
{
    public enum ErrorType
    {
        BadRequest = 400,
        Unauthorized = 401,
        InternalServerError = 500
    }
}
