﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Controllers;
using EShop.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace OnlineLibraryShop_Test

     

{
    public class ShippingControllerTests
    {
        [Fact]
        public async Task Get_Should_Return_OkResult_With_ShippingData()
        {
            // Arrange
            int customerId = 1;
            var expectedShippingData = new List<Shipping>(); // Replace with your actual expected data

            var shippingServiceMock = new Mock<IShippingService>();
            shippingServiceMock.Setup(service => service.GetShippingData(It.IsAny<GetShippingAddressByIdQuery>()))
              .ReturnsAsync(expectedShippingData);

            var controller = new ShippingController(shippingServiceMock.Object, null);

            // Act
            var result = await controller.Get(customerId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var shippingData = Assert.IsAssignableFrom<List<Shipping>>(okResult.Value);
            Assert.Equal(0,expectedShippingData.Count);
        }

    }
}
