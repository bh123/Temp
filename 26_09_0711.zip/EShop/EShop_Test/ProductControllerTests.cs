﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Controllers;
using EShop.Core.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace OnlineLibraryShop_Test
{
    public class ProductControllerTests
    {
        [Fact]
        public async Task Get_ReturnsOkObjectResult()
        {
            // Arrange
            var productServiceMock = new Mock<IProductService>();
            var controller = new ProductController(productServiceMock.Object);
            var expectedResult = new List<Product>(); 

            productServiceMock.Setup(x => x.GetProductList(It.IsAny<GetCartQueryHandler>()))
                .ReturnsAsync(expectedResult);

            // Act
            var result = await controller.Get();

            // Assert
            var okObjectResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<List<Product>>(okObjectResult.Value);
            Assert.Equal(expectedResult, model);
        }
    }
}
