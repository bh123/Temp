﻿using EShop.Infrastructure.Enum;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
namespace EShop.Filters
{
    public class CustomExceptionFilter : IExceptionFilter
    {
        private readonly ILogger<CustomExceptionFilter> _logger;

        public CustomExceptionFilter(ILogger<CustomExceptionFilter> logger)
        {
            _logger = logger;
        }

        public void OnException(ExceptionContext context)
        {
            _logger.LogError(context.Exception, "An unhandled exception occurred.");
            var statusCode = DetermineStatusCode(context.Exception);


            // You can customize the response here based on the exception type.
            var result = new ObjectResult(new
            {
                Message = "An error occurred.",
                Detail = context.Exception.Message,
                StackTrace = context.Exception.StackTrace,
                StatusCode = statusCode

            });
            //{
            //    StatusCode = (int)ErrorType.InternalServerError,  
            //};

            context.Result = result;
        }

        private int DetermineStatusCode(Exception exception)
        {
            if (exception is ArgumentException)
            {
                return (int)ErrorType.BadRequest;  
            }
            else if (exception is UnauthorizedAccessException)
            {
                return (int)ErrorType.Unauthorized;  
            }
            else
            {
                return (int)ErrorType.InternalServerError; 
            }
        }
    }
}
