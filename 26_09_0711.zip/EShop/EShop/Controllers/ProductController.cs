﻿using EShop.Application.Command;
using EShop.Application.IServices;
using Microsoft.AspNetCore.Mvc;

namespace EShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;
        public ProductController(IProductService productService)
        {

            _productService = productService;
        }

        /// <summary>
        /// Get List of Products
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Produces("application/json")]
        public async Task<ActionResult> Get()
        {
            GetCartQueryHandler query = new GetCartQueryHandler();
            var result  = await _productService.GetProductList(query);
            return Ok(result);
        }

    }
}
