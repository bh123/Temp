﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Application.Services;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using EShop.Application.Services;

namespace EShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartService _cartService;
        private IValidator<CreateCartCommand> _validator;
        private readonly IProductService _productService;
        private readonly ICustomerService _customerService;
        private ILogger<CartController> _logger;

        public CartController(ICartService cartService, 
                              IValidator<CreateCartCommand> validator, 
                              IProductService productService, 
                              ICustomerService customerService,
                              ILogger<CartController> logger)
        {
            _cartService = cartService;
            _validator = validator;
            _productService = productService;
            _customerService = customerService;
            _logger = logger;

        }
        /// <summary>
        /// Return Cart Details
        /// </summary>
        /// <param name="CustomerId"></param>
        /// <returns>ii</returns>
        // GET: api/<CartController>
        [HttpGet]
        [Produces("application/json")]
        public async Task<ActionResult> Get(int CustomerId)
        {
            GetCartItemQuery getCartItemQuery = new GetCartItemQuery();
            getCartItemQuery.CustomerId = CustomerId;
            var result = await _cartService.GetCartItem(getCartItemQuery);
            return Ok(result);
        }

        /// <summary>
        /// Create Cart functionality
        /// </summary>
        /// <param name="cartRequestCommand"></param>
        /// <returns></returns>
        // POST api/<CartController>
        [HttpPost]
        [Produces("application/json")]
        public async Task<ActionResult> Post([FromBody] CreateCartCommand cartRequestCommand)
        {
            _logger.LogInformation("Start Processing cart addding");

            var result = await _validator.ValidateAsync(cartRequestCommand);

            if (!result.IsValid)
            {
                var errors = result.Errors.Select(e => e.ErrorMessage).ToList();
                return BadRequest(errors);
            }
            var customer = await _customerService.GetCustomerById(new GetCustomerByIdQuery { CustomerId = cartRequestCommand.CustomerId });

            if (customer == null)
            {
                return NotFound("CustomerId is not valid");
            }

            var allowedProducts = await _productService.GetProductList(new GetCartQueryHandler { });
            var InvalidProductIds = cartRequestCommand.Items.Select(x => x.ProductId).ToList().Except(allowedProducts.Select(x => x.ProductId).ToList()).ToList();
            if (InvalidProductIds.Count() > 0)
            {
                return NotFound("Product not found for ids " + string.Join(",", InvalidProductIds));
            }
            _logger.LogInformation("End Processing card");

            var id = await _cartService.AddCartItems(cartRequestCommand);
            return CreatedAtAction(nameof(Post), new { id = id }, new { GenerateOrderId = id });

        }

    }
}
