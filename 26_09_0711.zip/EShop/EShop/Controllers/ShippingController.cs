﻿using EShop.Application.Command;
using EShop.Application.IServices;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;


namespace EShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShippingController : ControllerBase
    {
        private readonly IShippingService _shippingService;
        private IValidator<CreateShippingCommand> _validator;

        public ShippingController(IShippingService shippingService, IValidator<CreateShippingCommand> validator)
        {
            _shippingService = shippingService;
            _validator = validator;
        }
        /// <summary>
        /// Get Shipping Detail For customer
        /// </summary>
        /// <param name="CustomerId"></param>
        /// <returns></returns>
        // GET api/<ShippingController>/5
        [HttpGet()]
        [Produces("application/json")]
        public async Task<ActionResult> Get(int CustomerId)
        {
            GetShippingAddressByIdQuery query = new GetShippingAddressByIdQuery();
            query.CustomerId = CustomerId;
            var result = await _shippingService.GetShippingData(query);
            return Ok(result);
        }

        /// <summary>
        /// Create Shipping Date for customer
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        // POST api/<ShippingController>
        [HttpPost]
        [Produces("application/json")]
        public async Task<ActionResult> Post([FromBody] CreateShippingCommand command)
        {
            var result = await _validator.ValidateAsync(command);

            if (!result.IsValid)
            {
                var errors = result.Errors.Select(e => e.ErrorMessage).ToList();
                return BadRequest(errors);
            }
            var ShippingId = await _shippingService.InsertShippingAddress(command);

            return CreatedAtAction(nameof(Post), new { id = ShippingId }, new { ShippingId = ShippingId });
        }
    }
}
