﻿using EShop.Application.Command;
using EShop.Application.Dto;
using EShop.Application.IServices;
using EShop.Application.Order;
using EShop.Application.Services;
using EShop.Application.Validation;
using EShop.Core.Entities;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using System.Net;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace OnlineLibraryShop.Application.CustomServices
{
    public class OrderService : IOrderService
    {
        private readonly IMediator _mediator;

        private readonly IGenerateSlip _generateSlip;

        public OrderService(IMediator mediator, IGenerateSlip generateSlip)
        {
            _mediator = mediator;
            _generateSlip = generateSlip;
        }

        public async Task<ApiResponse<int>> CreatePurchaseOrder(Order order)
        {
            OrderEntity orderEntity = new OrderEntity();
            //convert order to order entity here 

            CreateOrderCommand createOrderCommand = new CreateOrderCommand() { payload = orderEntity };
            var orderid = await _mediator.Send(createOrderCommand);
            return new ApiResponse<int>
            {
                Data = orderid
            };

        }

        public async Task<bool> GenerateSlipIfRequired(Order order)
        {
            ShippingSlipEntity shipping = new ShippingSlipEntity();

            var orderResponse = await _mediator.Send(new GetOrderByIdQuery { OrderId = order.OrderId });
            var shippingResponse = await _mediator.Send(new GetShippingAddressByIdQuery { CustomerId = order.CustomerId });

            shipping.orderDetails = orderResponse;
            //shipping.shipping = shippingResponse.Data;
            if (shipping.orderDetails.Count > 0)
            {
                return _generateSlip.GeneratePdf(shipping);
            }
            return false;

        }

        public async Task<ApiResponse<List<string>>> ValidateOrderData(Order command)
        {
            return null;
            //List<string> errorList = new List<string>();
            //var customer = await _mediator.Send(new GetCustomerByIdQuery { CustomerId = command.CustomerId });
           
            
            //return errorList;
            //if (customer.HasError)
            //{
            //    errorList.Add("CustomerId is not valid");
            //}
            //var cartItem = await _mediator.Send(new GetCartItemQuery { CustomerId = command.CustomerId });

            //if (cartItem.HasError)
            //{
            //     errorList.Add("Cart should not be empty while place order");
            //}
            //if (errorList.Count > 0)
            //{
            //    return new ApiResponse<List<string>>
            //    {
            //        StatusCode = (int)HttpStatusCode.NotFound,
            //        Error = "invalid data",
            //        HasError = true,
            //        Data = errorList
            //    };
            //}
            //else
            //{
            //    return new ApiResponse<List<string>>
            //    {
            //        StatusCode = (int)HttpStatusCode.NotFound,
            //        Error = string.Empty,
            //        HasError = false,
            //        Data = errorList
            //    };
            //}
        }
    }
}
