﻿namespace EShop.Infrastructure.Consts
{
    public enum MembershipType
    {
        Membership = 1,
        NonMembership = 2
    }
}
