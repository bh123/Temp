﻿using EShop.Application.Command;
using EShop.Application.Services;
using EShop.Core.Entities;
using MediatR;
using Moq;
using Xunit;

namespace OnlineLibraryShop_Test
{
    public class CartServiceTests
    {
        [Fact]
        public async Task AddCartItems_Should_Return_OrderId()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var createCartRequestCommand = new CreateCartCommand();

            mediatorMock.Setup(m => m.Send(createCartRequestCommand, default)).ReturnsAsync(42);

            var cartService = new CartService(mediatorMock.Object);

            // Act
            int result = await cartService.AddCartItems(createCartRequestCommand);

            // Assert
            Assert.Equal(42, result);
        }
        [Fact]
        public async Task GetCartItem_Should_Return_CartItems()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var query = new GetCartItemQuery();

            var expectedCartItems = new List<CartItemDto>
        {
            new CartItemDto { Type  = "MemberShip" },
            new CartItemDto {  Type = "MemberShip" },
        };

            mediatorMock.Setup(m => m.Send(query, default)).ReturnsAsync(expectedCartItems);

            var cartService = new CartService(mediatorMock.Object);

            // Act
            List<CartItemDto> result = await cartService.GetCartItem(query);

            // Assert
            Assert.Equal(expectedCartItems, result);
        }
    }
}
