﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Application.Order;
using EShop.Application.Validation;
using EShop.Core.Entities;
using MediatR;

namespace OnlineLibraryShop.Application.CustomServices
{
    public class OrderService : IOrderService
    {
        private readonly IMediator _mediator;

        private readonly IGenerateSlip _generateSlip;

        public OrderService(IMediator mediator, IGenerateSlip generateSlip)
        {
            _mediator = mediator;
            _generateSlip = generateSlip;
        }

        public async Task<int> CreatePurchaseOrder(CreateOrderCommand createOrderCommand)
        {
            int OrderId = await _mediator.Send(createOrderCommand);
            return OrderId;
        }

        public async Task GenerateSlipIfRequired(int OrderId,int CustomerId)
        {
            ShippingSlipDto shipping = new ShippingSlipDto();

            var orderDto = await _mediator.Send(new GetOrderByIdQuery { OrderId = OrderId });
            var ShippingDetail = await _mediator.Send(new GetShippingAddressByIdQuery { CustomerId = CustomerId });

            shipping.orderDetails= orderDto;
            shipping.shipping = ShippingDetail;
            if (shipping.orderDetails.Count > 0)
            {
                _generateSlip.GeneratePdf(shipping);
            }

        }
    }
}
