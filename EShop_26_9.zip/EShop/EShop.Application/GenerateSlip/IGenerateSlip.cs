﻿using EShop.Core.Entities;

namespace EShop.Application.Validation
{
    public interface IGenerateSlip
    {
        void GeneratePdf(ShippingSlipDto order);

    }
}
