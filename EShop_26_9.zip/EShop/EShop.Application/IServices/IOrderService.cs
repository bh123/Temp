﻿using EShop.Application.Order;

namespace EShop.Application.IServices
{
    public interface IOrderService
    {
        Task<int> CreatePurchaseOrder(CreateOrderCommand purchaseRequestDto);


        Task GenerateSlipIfRequired(int OrderId, int CustomerId);

    }
}
