﻿
using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Command
{
    public class GetShippingAddressByIdQuery : IRequest<List<Shipping>>
    {
        public int CustomerId { get; set; }

    }
}
