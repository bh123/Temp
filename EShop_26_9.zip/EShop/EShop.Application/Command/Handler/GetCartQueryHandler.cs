﻿using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;

namespace EShop.Application.Command.Handler
{
    public class GetCartQueryHandler : IRequestHandler<GetCartItemQuery, List<CartItemDto>>
    {
        private readonly ICartRepository _cartRepository;
        public GetCartQueryHandler(ICartRepository cartRepository)
        {
            _cartRepository = cartRepository;
        }

        public async Task<List<CartItemDto>> Handle(GetCartItemQuery request, CancellationToken cancellationToken)
        {
            var result = await _cartRepository.getCartItem(request.CustomerId);
            return result;
        }
    }
}
