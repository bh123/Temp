﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Application.Order;
using EShop.Application.Services;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using OnlineLibraryShop.Application.CustomServices;

namespace EShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly ICartService _cartService;
        private readonly IValidator<CreateOrderCommand> _validator;
        private readonly ICustomerService _customerService;

        public OrderController(IOrderService orderService, ICartService cartService, IValidator<CreateOrderCommand> validator, ICustomerService customerService)
        {
            _orderService = orderService;
            _cartService = cartService;
            _validator = validator;
            _customerService = customerService;
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] CreateOrderCommand command)
        {
            var validationResult = _validator.Validate(command);

            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors);
            }
            var customer = _customerService.GetCustomerById(new GetCustomerByIdQuery { CustomerId = command.CustomerId });
            if (customer == null)
            {
                NotFound("CustomerId is not valid");
            }

            var cartItem = await _cartService.GetCartItem(new GetCartItemQuery { CustomerId = command.CustomerId });
            if (cartItem != null && cartItem.Count == 0)
            {
                return BadRequest("Cart should not be empty while place order");
            }

            int OrderId = await _orderService.CreatePurchaseOrder(command);
            await _orderService.GenerateSlipIfRequired(OrderId,command.CustomerId);
            return CreatedAtAction(nameof(Post), new { id = OrderId }, new { GenerateOrderId = OrderId });

        }
    }
}
