using EShop.Core.Entities;

namespace OnlineLibraryShop.Core.Interfaces
{
    public interface IOrderRepository
    {
        Task<int> CreatePurchaseOrder(OrderEntity purchaseRequest);

        Task<List<OrderEntity>> GetPurchaseOrderDetail(int PurchaseOrderId);

    }
}
