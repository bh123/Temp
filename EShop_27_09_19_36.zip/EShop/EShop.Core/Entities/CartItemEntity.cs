﻿using System.ComponentModel.DataAnnotations;

namespace EShop.Core.Entities
{
    public class CartItemEntity
    {
        public string Type { get; set; }
        public int Quantity { get; set; }
        [Required]
        public int ProductId { get; set; }
        
    }
}
