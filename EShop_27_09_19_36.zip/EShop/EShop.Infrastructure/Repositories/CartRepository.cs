﻿using AutoMapper;
using Dapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using EShop.Infrastructure.Consts;
using EShop.Infrastructure.DataModel;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace EShop.Infrastructure.Repositories
{
    public class CartRepository : ICartRepository
    {
        protected readonly IDbConnectionFactory _dbConnectionFactory;
        protected readonly IConfiguration _configuration;
        private readonly IMapper _mapper;

        public CartRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration, IMapper mapper)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
            _mapper = mapper;
        }

        public async Task<int> AddCartItem(CartEntity purchaseRequest)
        {

            var cartModel =  _mapper.Map<CartDataModel>(purchaseRequest);

            int cartId = 0;
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@CustomerId", cartModel.CustomerId);

            DataTable itemsTable = new DataTable();
            itemsTable.Columns.Add("ProductId", typeof(int));
            itemsTable.Columns.Add("Quantity", typeof(int));
            itemsTable.Columns.Add("Discount", typeof(decimal));
            itemsTable.Columns.Add("IsLoyaltyMemberShip", typeof(bool));

            if (cartModel.Items != null && cartModel.Items.Count > 0)
            {
                foreach (var item in purchaseRequest.Items)
                {
                    bool IsMemberShip = false;
                    if (item.Type.ToLower() == MembershipType.Membership.ToString().ToLower())
                    {
                        IsMemberShip = true;
                    }

                    if (IsMemberShip)
                    {
                        itemsTable.Rows.Add(item.ProductId, item.Quantity, 0, IsMemberShip);
                    }
                    else
                    {
                        itemsTable.Rows.Add(item.ProductId, item.Quantity, 0, IsMemberShip);
                    }
                }

                using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
                {
                    dbConnection.Open();
                    dynamicParameters.Add("@Items", itemsTable.AsTableValuedParameter("dbo.PurchaseItemTableType"));
                    cartId = await dbConnection.ExecuteScalarAsync<int>("InsertProductInCart", dynamicParameters, commandType: CommandType.StoredProcedure);
                }
            }

            return cartId;
        }
        public async Task<List<CartItemEntity>> getCartItem(int CustomerID)
        {
            List<CartItemEntity> cartItemList = new List<CartItemEntity>();

            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {

                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@CustomerId", CustomerID);

                dbConnection.Open();

                // Define the stored procedure call using Dapper
                var parameters = new { Id = CustomerID };
                var cartitem = await dbConnection.QueryAsync<CartDataItemModel>("GetCartsDetailByCustomerId", dynamicParameters, commandType: CommandType.StoredProcedure);

                cartItemList = _mapper.Map<List<CartItemEntity>>(cartitem);

                return cartItemList;
            }

        }


    }
}
