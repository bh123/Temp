﻿using EShop.Application.Dto;
using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Command
{
    public class CreateCartCommand : IRequest<int>
    {
       public  CartEntity payload { get; set; }
    }
}
