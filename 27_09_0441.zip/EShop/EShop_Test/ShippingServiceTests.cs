﻿using EShop.Application.Command;
using EShop.Application.Services;
using EShop.Core.Entities;
using MediatR;
using Moq;
using Xunit;

namespace OnlineLibraryShop_Test
{
    public class ShippingServiceTests
    {
        [Fact]
        public async Task GetShippingData_ReturnsShippingList()
        {
            //// Arrange
            //var mediatorMock = new Mock<IMediator>();
            //var shippingService = new ShippingService(mediatorMock.Object);
            //var query = new GetShippingAddressByIdQuery(); // You should set up your query object as needed.

            //var expectedShippingList = new List<Shipping>(); // Define your expected result.

            //mediatorMock.Setup(x => x.Send(It.IsAny<GetShippingAddressByIdQuery>(), default(CancellationToken)))
            //    .ReturnsAsync(expectedShippingList);

            //// Act
            //var result = await shippingService.GetShippingData(query);

            //// Assert
            //Assert.NotNull(result);
            //Assert.Same(expectedShippingList, result);
        }

        [Fact]
        public async Task InsertShippingAddress_ReturnsOrderId()
        {
            // Arrange
            //var mediatorMock = new Mock<IMediator>();
            //var shippingService = new ShippingService(mediatorMock.Object);
            //var shippingCommand = new CreateShippingCommand(); // You should set up your command object as needed.

            //int expectedOrderId = 123; // Define your expected result.

            //mediatorMock.Setup(x => x.Send(It.IsAny<CreateShippingCommand>(), default(CancellationToken)))
            //    .ReturnsAsync(expectedOrderId);

            //// Act
            //var result = await shippingService.InsertShippingAddress(shippingCommand);

            //// Assert
            //Assert.Equal(expectedOrderId, result);
        }
    }
}
