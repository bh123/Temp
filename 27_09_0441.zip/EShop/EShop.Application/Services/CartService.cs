﻿using EShop.Application.Command;
using EShop.Application.Command.Handler;
using EShop.Application.Dto;
using EShop.Application.IServices;
using EShop.Core.Entities;
using MediatR;
using System.Net;

namespace EShop.Application.Services
{
    public class CartService : ICartService
    {
        private readonly IMediator _mediator;

        public CartService(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<ApiResponse<int>> AddCartItems(Cart cart)
        {
            CartEntity cartEntity = new CartEntity();
            CreateCartCommand command = new CreateCartCommand() { payload = cartEntity };
            var result = await _mediator.Send(command);

            return new ApiResponse<int>()
            {
                Data = result,
                HasError = false,
                Error = "",
                StatusCode = (int)HttpStatusCode.OK
            };



             
        }

        public async Task<ApiResponse<List<CartItem>>> GetCartItem(Cart cart)
        {
            List<CartItem> cartItems = new List<CartItem>();
            var resultCartItem = await _mediator.Send(new GetCartItemQuery { CustomerId = cart.CustomerId });

            return new ApiResponse<List<CartItem>>()
            {
                Data = cartItems,
                HasError = false,
                Error = "",
                StatusCode = (int)HttpStatusCode.OK
            };

            


        }
        public async Task<ApiResponse<List<string>>> ValidatCartInvalidData(Cart cart)
        {
            List<string> customerErrors = new List<string>();
            var customer = await _mediator.Send(new GetCustomerByIdQuery { CustomerId = cart.CustomerId });
            //if (customer.HasError)
            //{
            //    customerErrors.Add("Customer not found");
            //}
            var allowedProducts = await _mediator.Send(new GetCartItemQuery{CustomerId=cart.CustomerId });

            var invalidProductIds = cart.Items.Select(x => x.ProductId).ToList().Except(allowedProducts.Select(x => x.ProductId).ToList()).ToList();
            if (invalidProductIds.Count() > 0)
            {
                customerErrors.Add("Product not found for ids " + string.Join(",", invalidProductIds));
            }
            if (customerErrors.Count() > 0)
            {
                return new ApiResponse<List<string>>
                {
                    StatusCode = (int)HttpStatusCode.BadRequest,
                    Data = customerErrors,
                    Error = "Invalid data",
                    HasError = true
                };
            }
            else
            {
                return new ApiResponse<List<string>>
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Data = customerErrors,
                    Error = string.Empty,
                    HasError = false
                };
            }
        }
    }

}
