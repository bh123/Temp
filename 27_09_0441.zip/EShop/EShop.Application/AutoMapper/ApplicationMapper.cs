﻿using AutoMapper;
using EShop.Application.Command;
using EShop.Application.Dto;
using EShop.Application.Order;
using EShop.Core.Entities;

namespace EShop.Application.AutoMapper
{
    public class ApplicationMapper : Profile
    {
        public ApplicationMapper()
        {
            CreateMap<PurchaseRequestDto, CreateOrderCommand>().ReverseMap();
            CreateMap<CreateCartCommand, CartPurchaseItems>().ReverseMap();
            //CreateMap<CreateShippingCommand, Shipping>().ReverseMap();
             CreateMap<Cart, CartEntity>().ReverseMap();

            
        }
    }
}
    

