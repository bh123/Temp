﻿using EShop.Application.Command;
using EShop.Application.Dto;
using EShop.Core.Entities;

namespace EShop.Application.IServices
{
    public interface ICartService
    {
        Task<ApiResponse<int>> AddCartItems(Cart cart);

        Task<ApiResponse<List<Dto.CartItem>>> GetCartItem(Cart cart);
        Task<ApiResponse<List<string>>> ValidatCartInvalidData(Cart cart);
    }
}
