﻿namespace EShop.Core.Entities
{
    public class OrderEntity
    {
        public int CustomerId { get; set; }
        public int ShipId { get; set; }
        public bool IncludeLoyaltyMembership { get; set; }


    }
}
