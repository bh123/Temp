﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop.Infrastructure.DataModel
{
    public class CartDataItemModelList
    {
        public List<CartDataItemModel> list { get; set; }
    }
}
