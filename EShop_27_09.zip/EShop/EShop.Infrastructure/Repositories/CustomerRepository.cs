﻿using Dapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace EShop.Infrastructure.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        protected readonly IDbConnectionFactory _dbConnectionFactory;
        protected readonly IConfiguration _configuration;
        public CustomerRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
        }
        public async Task<Customer> GetCustomerById(int CustomerId)
        {
            Customer customer = new Customer();

            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {

                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@CustomerId", CustomerId);

                dbConnection.Open();

                // Define the stored procedure call using Dapper
                var parameters = new { Id = CustomerId };
                customer = await dbConnection.QueryFirstOrDefaultAsync<Customer>("GetCustomerById", dynamicParameters, commandType: CommandType.StoredProcedure);
                return customer;
            }
        }
    }
}
