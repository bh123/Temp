﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Application.Order;
using EShop.Application.Services;
using EShop.Core.Entities;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using OnlineLibraryShop.Application.CustomServices;
using System.Net;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace EShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly ICartService _cartService;
        private readonly IValidator<CreateOrderCommand> _validator;
        private readonly ICustomerService _customerService;

        public OrderController(IOrderService orderService, ICartService cartService, IValidator<CreateOrderCommand> validator, ICustomerService customerService)
        {
            _orderService = orderService;
            _cartService = cartService;
            _validator = validator;
            _customerService = customerService;
        }
        /// <summary>
        /// User can place Order
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Produces("application/json")]
        public async Task<ActionResult> Post([FromBody] CreateOrderCommand command)
        {
            var validationResult = _validator.Validate(command);

            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors);
            }
            // await ValidateInvalidInput(command);
            var dataValidationResult = await _orderService.ValidateOrderData(command);
            if(dataValidationResult.HasError)
            {
                return BadRequest(dataValidationResult.Data);
            }

            var order = await _orderService.CreatePurchaseOrder(command);
            if (order.HasError)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
            else
            {
                return CreatedAtAction(nameof(Post), new { id = order.Data }, new { GenerateOrderId = order.Data });
            }
        }
        /// <summary>
        /// Generate Shipping Slip on Specified location
        /// </summary>
        /// <param name="generateSlipInput"></param>
        /// <returns></returns>
        [HttpPost(Name = "GenerateShippingSlip")]
        [ActionName("GenerateShippingSlip")]
        public async Task<ActionResult> GenerateShippingSlip([FromBody] GenerateSlipInput generateSlipInput)
        {
            bool IsGenerated = await _orderService.GenerateSlipIfRequired(generateSlipInput.OrderId, generateSlipInput.CustomerId);
            if (IsGenerated)
            {
                return Ok();
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
     }
}
