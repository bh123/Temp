using EShop.Core.Entities;

namespace OnlineLibraryShop.Core.Interfaces
{
    public interface IOrderRepository
    {
        Task<int> CreatePurchaseOrder(PurchaseRequestDto purchaseRequest);

        Task<List<GetOrderDetail>> GetPurchaseOrderDetail(int PurchaseOrderId);

    }
}
