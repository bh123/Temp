﻿using EShop.Core.Entities;

namespace EShop.Core.Interfaces
{
    public interface ICustomerRepository
    {
         Task<Customer> GetCustomerById(int CustomerId);


    }
}
