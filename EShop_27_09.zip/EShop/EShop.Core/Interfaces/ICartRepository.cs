﻿using EShop.Core.Entities;

namespace EShop.Core.Interfaces
{
    public interface ICartRepository
    {
       Task<int> AddCartItem(CartPurchaseItems cartPurchaseItems);

        Task<List<CartItemDto>> getCartItem(int CustomerID);

    }
}
