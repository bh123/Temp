﻿using EShop.Core.Entities;

namespace EShop.Core.Interfaces
{
    public interface IShippingRepository
    {
       Task<int> InsertShippingData(Shipping shipping);
        Task<List<Shipping>> GetShippingData(int CustomerId);

    }
}
