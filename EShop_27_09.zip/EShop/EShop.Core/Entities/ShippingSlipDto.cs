﻿namespace EShop.Core.Entities
{
    public class ShippingSlipDto
    {
        public List<GetOrderDetail> orderDetails { get; set; }
        public List<Shipping> shipping { get; set; }
    }
}
