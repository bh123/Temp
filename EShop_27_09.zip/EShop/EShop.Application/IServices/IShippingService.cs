﻿using EShop.Application.Command;
using EShop.Core.Entities;

namespace EShop.Application.IServices
{
    public interface IShippingService
    {
      Task<ApiResponse<int>> InsertShippingAddress(CreateShippingCommand shipping);

        Task<ApiResponse<List<Shipping>>> GetShippingData(GetShippingAddressByIdQuery query);

    }
}
