﻿using EShop.Application.Order;
using EShop.Core.Entities;
using Microsoft.AspNetCore.Mvc;

namespace EShop.Application.IServices
{
    public interface IOrderService
    {
        Task<ApiResponse<int>> CreatePurchaseOrder(CreateOrderCommand purchaseRequestDto);

        Task<bool> GenerateSlipIfRequired(int OrderId, int CustomerId);

        Task<ApiResponse<List<string>>> ValidateOrderData(CreateOrderCommand command);



    }
}
