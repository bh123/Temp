﻿using EShop.Application.Command;
using EShop.Core.Entities;

namespace EShop.Application.IServices
{
    public interface ICartService
    {
        Task<ApiResponse<int>> AddCartItems(CreateCartCommand createCartRequestCommand);

        Task<ApiResponse<List<CartItemDto>>> GetCartItem(GetCartItemQuery query);
        Task<ApiResponse<List<string>>> ValidatCartInvalidData(CreateCartCommand cartRequestCommand);
    }
}
