﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Core.Entities;
using MediatR;
using System.Collections.Generic;
using System.Net;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace EShop.Application.Services
{
    public class CartService : ICartService
    {
        private readonly IMediator _mediator;

        public CartService(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<ApiResponse<int>> AddCartItems(CreateCartCommand createCartRequestCommand)
        {
            var result = await _mediator.Send(createCartRequestCommand);
            return result;
        }

        public async Task<ApiResponse<List<CartItemDto>>> GetCartItem(GetCartItemQuery query)
        {
            var cartItems = await _mediator.Send(query);
            return cartItems;
        }
        public async Task<ApiResponse<List<string>>> ValidatCartInvalidData(CreateCartCommand cartRequestCommand)
        {
            List<string> customerErrors = new List<string>();
            var customer = await _mediator.Send(new GetCustomerByIdQuery { CustomerId = cartRequestCommand.CustomerId });
            if (customer.HasError)
            {
                customerErrors.Add("Customer not found");
            }
            var allowedProducts = await _mediator.Send(new GetCartQueryHandler { });

            var invalidProductIds = cartRequestCommand.Items.Select(x => x.ProductId).ToList().Except(allowedProducts.Data.Select(x => x.ProductId).ToList()).ToList();
            if (invalidProductIds.Count() > 0)
            {
                customerErrors.Add("Product not found for ids " + string.Join(",", invalidProductIds));
            }
            if (customerErrors.Count() > 0)
            {
                return new ApiResponse<List<string>>
                {
                    StatusCode = (int)HttpStatusCode.BadRequest,
                    Data = customerErrors,
                    Error = "Invalid data",
                    HasError = true
                };
            }else
            {
                return new ApiResponse<List<string>>
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Data = customerErrors,
                    Error = string.Empty,
                    HasError = false
                };
            }
        }
    }

}
