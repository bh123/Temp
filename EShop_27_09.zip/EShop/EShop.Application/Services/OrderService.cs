﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Application.Order;
using EShop.Application.Services;
using EShop.Application.Validation;
using EShop.Core.Entities;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using System.Net;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace OnlineLibraryShop.Application.CustomServices
{
    public class OrderService : IOrderService
    {
        private readonly IMediator _mediator;

        private readonly IGenerateSlip _generateSlip;

        public OrderService(IMediator mediator, IGenerateSlip generateSlip)
        {
            _mediator = mediator;
            _generateSlip = generateSlip;
        }

        public async Task<ApiResponse<int>> CreatePurchaseOrder(CreateOrderCommand createOrderCommand)
        {
            var orderid = await _mediator.Send(createOrderCommand);
            return orderid;
        }

        public async Task<bool> GenerateSlipIfRequired(int OrderId, int CustomerId)
        {
            ShippingSlipDto shipping = new ShippingSlipDto();

            var orderResponse = await _mediator.Send(new GetOrderByIdQuery { OrderId = OrderId });
            var shippingResponse = await _mediator.Send(new GetShippingAddressByIdQuery { CustomerId = CustomerId });

            shipping.orderDetails = orderResponse.Data;
            shipping.shipping = shippingResponse.Data;
            if (shipping.orderDetails.Count > 0)
            {
                return _generateSlip.GeneratePdf(shipping);
            }
            return false;

        }

        public async Task<ApiResponse<List<string>>> ValidateOrderData(CreateOrderCommand command)
        {
            List<string> errorList = new List<string>();
            var customer = await _mediator.Send(new GetCustomerByIdQuery { CustomerId = command.CustomerId });
            if (customer.HasError)
            {
                errorList.Add("CustomerId is not valid");
            }
            var cartItem = await _mediator.Send(new GetCartItemQuery { CustomerId = command.CustomerId });

            if (cartItem.HasError)
            {
                 errorList.Add("Cart should not be empty while place order");
            }
            if (errorList.Count > 0)
            {
                return new ApiResponse<List<string>>
                {
                    StatusCode = (int)HttpStatusCode.NotFound,
                    Error = "invalid data",
                    HasError = true,
                    Data = errorList
                };
            }
            else
            {
                return new ApiResponse<List<string>>
                {
                    StatusCode = (int)HttpStatusCode.NotFound,
                    Error = string.Empty,
                    HasError = false,
                    Data = errorList
                };
            }
        }
    }
}
