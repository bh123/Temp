﻿using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;
using System.Net;

namespace EShop.Application.Command.Handler
{
    public class GetCustomerByIdQueryHandler : IRequestHandler<GetCustomerByIdQuery, ApiResponse<Customer>>
    {
        private readonly ICustomerRepository _customerRepository;
        public GetCustomerByIdQueryHandler(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }
        public async Task<ApiResponse<Customer>> Handle(GetCustomerByIdQuery request, CancellationToken cancellationToken)
        {

            var customer = await _customerRepository.GetCustomerById(request.CustomerId);
            if(customer!=null)
            {
                return new ApiResponse<Customer>
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Data = customer,
                    Error = string.Empty,
                    HasError = false
                };
            }
            else
            {
                return new ApiResponse<Customer>
                {
                    StatusCode = (int)HttpStatusCode.NotFound,
                    Data = customer,
                    Error = "Customer not found",
                    HasError = true
                };
            }
             
        }
    }
}
