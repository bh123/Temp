﻿using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;
using System.Net;

namespace EShop.Application.Command.Handler
{
    public class GetProductQueryHandler : IRequestHandler<Command.GetCartQueryHandler, ApiResponse<List<Product>>>
    {
        private readonly IProductRepository _productRepository;
        public GetProductQueryHandler(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public async Task<ApiResponse<List<Product>>> Handle(Command.GetCartQueryHandler request, CancellationToken cancellationToken)
        {
            var products = await _productRepository.GetProductList();
            if (products != null && products.Count() > 0)
            {
                return new ApiResponse<List<Product>>
                {
                    Data = products,
                    Error = string.Empty,
                    HasError = false,
                    StatusCode = (int)HttpStatusCode.OK
                };
            }
            else
            {
                return new ApiResponse<List<Product>>
                {
                    Data = products,
                    Error = "Not Data Found",
                    HasError = true,
                    StatusCode = (int)HttpStatusCode.NotFound
                };
            }
        }

    }
}
