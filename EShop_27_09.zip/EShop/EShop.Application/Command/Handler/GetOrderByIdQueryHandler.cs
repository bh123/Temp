﻿using EShop.Application.Order;
using EShop.Core.Entities;
using MediatR;
using OnlineLibraryShop.Core.Interfaces;
using System.Net;

namespace OnlineLibraryShop.Application.Command.Handler
{
    public class GetOrderByIdQueryHandler : IRequestHandler<GetOrderByIdQuery, ApiResponse<List<GetOrderDetail>>>
    {
        private readonly IOrderRepository _orderRepository;
        public GetOrderByIdQueryHandler(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }
        public async Task<ApiResponse<List<GetOrderDetail>>> Handle(GetOrderByIdQuery request, CancellationToken cancellationToken)
        {
            var result = await _orderRepository.GetPurchaseOrderDetail(request.OrderId);

            if (result != null && result.Count > 0)
            {
                return new ApiResponse<List<GetOrderDetail>>
                {
                    Data = result,
                    Error = string.Empty,
                    HasError = false,
                    StatusCode = (int)HttpStatusCode.OK
                };
            }
            else
            {
                return new ApiResponse<List<GetOrderDetail>>
                {
                    Data = result,
                    Error = "No Record Found",
                    HasError = true,
                    StatusCode = (int)HttpStatusCode.NotFound
                };
            }
        }
    }
}
