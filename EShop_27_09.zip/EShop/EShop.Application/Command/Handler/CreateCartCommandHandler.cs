﻿using AutoMapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;
using System.Net;

namespace EShop.Application.Command.Handler
{
    public class CreateCartCommandHandler : IRequestHandler<CreateCartCommand, ApiResponse<int>>
    {
        private readonly ICartRepository _cartRepository;
         private readonly IMapper _mapper;
        public CreateCartCommandHandler(ICartRepository cartRepository, IMapper mapper)
        {
            _mapper = mapper;
            _cartRepository = cartRepository;
        }
        public async Task<ApiResponse<int>> Handle(CreateCartCommand command, CancellationToken cancellationToken)
        {
            var CartItemDto = _mapper.Map<CartPurchaseItems>(command);
            var CartId = await _cartRepository.AddCartItem(CartItemDto);
            if(CartId>0)
            {
                return new ApiResponse<int>
                {
                    Data = CartId,
                    StatusCode = (int)HttpStatusCode.OK,
                    Error = "",
                    HasError = false
                };
            }
            else
            {
                return new ApiResponse<int>
                {
                    Data = CartId,
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Error = "Not Found",
                    HasError = true
                };
            }
             
        }
    }
}
