﻿using AutoMapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;
using System.Net;

namespace EShop.Application.Command.Handler
{
    public class CreateShippingCommandHandler : IRequestHandler<CreateShippingCommand, ApiResponse<int>>
    {
        private readonly IShippingRepository _shippingRepository;
        private readonly IMapper _mapper;

        public CreateShippingCommandHandler(IShippingRepository shippingRepository, IMapper mapper)
        {
            _shippingRepository = shippingRepository;
            _mapper = mapper;
        }

        public async Task<ApiResponse<int>> Handle(CreateShippingCommand request, CancellationToken cancellationToken)
        {
            var shipping = _mapper.Map<Shipping>(request);
            var result = await _shippingRepository.InsertShippingData(shipping);
            if (result > 0)
            {
                return new ApiResponse<int>
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Data = result,
                    Error = string.Empty,
                    HasError = false
                };
            }
            else
            {
                return new ApiResponse<int>
                {
                    StatusCode = (int)HttpStatusCode.NotFound,
                    Data = result,
                    Error = "Not Found",
                    HasError = true
                };
            }
        }
    }
}
