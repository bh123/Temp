﻿using AutoMapper;
using EShop.Application.Order;
using EShop.Core.Entities;
using MediatR;
using OnlineLibraryShop.Core.Interfaces;
using System.Net;

namespace OnlineLibraryShop.Application.Command.Handler
{
    public class CreateOrderCommandHandler : IRequestHandler<CreateOrderCommand, ApiResponse<int>>
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IMapper _mapper;

        public CreateOrderCommandHandler(IOrderRepository orderRepository, IMapper mapper)
        {
            _orderRepository = orderRepository;
            _mapper = mapper;
        }
        public async Task<ApiResponse<int>> Handle(CreateOrderCommand command, CancellationToken cancellationtoken)
        {
            var purchaseRequestDto = _mapper.Map<PurchaseRequestDto>(command);
            int Orderid = await _orderRepository.CreatePurchaseOrder(purchaseRequestDto);
            if (Orderid > 0)
            {
              return  new ApiResponse<int>
                {
                    Data = Orderid,
                    HasError = false,
                    Error = string.Empty,
                    StatusCode = (int)HttpStatusCode.Created
                };
            }
            else
            {
                return new ApiResponse<int>
                {
                    Data = Orderid,
                    HasError = true,
                    Error = "Order not places",
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

    }
}
