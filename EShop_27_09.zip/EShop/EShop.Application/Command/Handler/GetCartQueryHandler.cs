﻿using EShop.Core.Entities;
using EShop.Core.Interfaces;
using MediatR;
using System.Net;

namespace EShop.Application.Command.Handler
{
    public class GetCartQueryHandler : IRequestHandler<GetCartItemQuery, ApiResponse<List<CartItemDto>>>
    {
        private readonly ICartRepository _cartRepository;
        public GetCartQueryHandler(ICartRepository cartRepository)
        {
            _cartRepository = cartRepository;
        }

        public async Task<ApiResponse<List<CartItemDto>>> Handle(GetCartItemQuery request, CancellationToken cancellationToken)
        {
            var result = await _cartRepository.getCartItem(request.CustomerId);
            if (result != null && result.Count > 0)
            {
                return new ApiResponse<List<CartItemDto>>
                {
                    Data = result,
                    StatusCode = (int)HttpStatusCode.OK,
                    Error = "",
                    HasError = false
                };

            }
            else
            {
              return  new ApiResponse<List<CartItemDto>>
                {
                    Data = result,
                    StatusCode = (int)HttpStatusCode.NotFound,
                    Error = "",
                    HasError = true
                };
            }

        }
    }
}
