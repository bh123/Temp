﻿using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Command
{
    public class GetCartQueryHandler : IRequest<ApiResponse<List<Product>>>
    {
    }
}
