﻿using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Command
{
    public class CreateShippingCommand : IRequest<ApiResponse<int>>
    {
        public int CustomerId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }

        public string Country { get; set; }

        public string ZipCode { get; set; }
        public bool IsActive { get; set; }
    }
}
