﻿
using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Command
{
    public class GetShippingAddressByIdQuery : IRequest<ApiResponse<List<Shipping>>>
    {
        public int CustomerId { get; set; }

    }
}
