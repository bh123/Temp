﻿using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Order
{
    public class CreateOrderCommand : IRequest<ApiResponse<int>>
    {
        public int CustomerId { get; set; }
        public int ShipId { get; set; }
        public bool IncludeLoyaltyMemberShip { get; set; }  
    }
}
