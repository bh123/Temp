﻿using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Command
{
    public class CreateCartCommand : IRequest<ApiResponse<int>>
    {
        public int CustomerId { get; set; }
        public List<CartItemDto> Items { get; set; }
    }
}
