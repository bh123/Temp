﻿using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Order
{
    public class GetOrderByIdQuery : IRequest<ApiResponse<List<GetOrderDetail>>>
    {
        public int OrderId { get; set; }
    }
}
