﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace OnlineLibraryShop_Test
{
    public class CheckOutControllerTests
    {
        [Fact]
        public async Task Post_ValidCommand_ReturnsCreatedAtAction()
        {
            // Arrange
            var checkoutServiceMock = new Mock<ICheckOutService>();
            var orderServiceMock = new Mock<IOrderService>();

            var controller = new CheckOutController(checkoutServiceMock.Object, orderServiceMock.Object);
            var command = new CheckoutCommand();

            checkoutServiceMock.Setup(x => x.Checkout(command)).ReturnsAsync(123); // Simulate a successful checkout

            // Act
            var result = await controller.Post(command);

            // Assert
            var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result);
            Assert.Equal(nameof(CheckOutController.Post), createdAtActionResult.ActionName);
            Assert.Equal(123, createdAtActionResult.RouteValues["id"]);
        }

    }
}
