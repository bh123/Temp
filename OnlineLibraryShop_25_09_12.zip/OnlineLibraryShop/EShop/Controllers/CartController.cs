﻿using EShop.Application.Command;
using EShop.Application.IServices;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;


namespace EShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartService _cartService;
        private IValidator<CreateCartCommand> _validator;


        public CartController(ICartService cartService, IValidator<CreateCartCommand> validator)
        {
            _cartService = cartService;
            _validator = validator;
        }

        // GET: api/<CartController>
        [HttpGet]
        public async Task<ActionResult> Get(int CustomerId)
        {
            GetCartItemQuery getCartItemQuery= new GetCartItemQuery();
            getCartItemQuery.CustomerId = CustomerId;
            var result = await _cartService.GetCartItem(getCartItemQuery);
            return Ok(result);
        }

        // POST api/<CartController>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] CreateCartCommand cartRequestCommand)
        {
            var result = await _validator.ValidateAsync(cartRequestCommand);

            if (!result.IsValid)
            {
                var errors = result.Errors.Select(e => e.ErrorMessage).ToList();
                return BadRequest(errors);
            }
            var id = await _cartService.AddCartItems(cartRequestCommand);
            return CreatedAtAction(nameof(Post), new { id = id }, new { GenerateOrderId = id });

        }

    }
}
