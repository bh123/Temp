using System.ComponentModel.DataAnnotations;

namespace OnlineLibraryShop.Core.Entities
{
    public class PurchaseItemDto
    {
        [Required]
        public string Type { get; set; }
        public int Qty { get; set; }
        [Required]
        public string ProductName { get; set; }

    }
}