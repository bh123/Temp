﻿using EShop.Application.Command;
using EShop.Application.IServices;
using EShop.Core.Entities;
using MediatR;

namespace EShop.Application.Services
{
    public class ShippingService : IShippingService
    {
        private readonly IMediator _mediator;

        public ShippingService(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<List<Shipping>> GetShippingData(GetShippingAddressByIdQuery query)
        {
            var result = await _mediator.Send(query);
            return result;
        }

        public async Task<int> InsertShippingAddress(CreateShippingCommand shipping)
        {
            int OrderId = await _mediator.Send(shipping);
            return OrderId;
        }
    }
}
