﻿using AutoMapper;
using EShop.Application.Command;
using EShop.Core.Entities;
using MediatR;
using OnlineLibraryShop.Core.Interfaces;

namespace OnlineLibraryShop.Application.Command.Handler
{
    public class CreateMemberShipCommandHandler : IRequestHandler<CreateMemberShipCommand>
    {
        private readonly IMemberShipRepository _memberShipRepository;
        private readonly IMapper _mapper;


        public CreateMemberShipCommandHandler(IMemberShipRepository memberShipRepository, IMapper mapper)
        {
            _memberShipRepository = memberShipRepository;
            _mapper = mapper;
        }
        public async Task Handle(CreateMemberShipCommand command, CancellationToken cancellationToken)
        {
 
           var memberShipDto = _mapper.Map<MemberShipDto>(command);

            await _memberShipRepository.AddUpdateMeberShipDetails(memberShipDto);
        }

    }
}
