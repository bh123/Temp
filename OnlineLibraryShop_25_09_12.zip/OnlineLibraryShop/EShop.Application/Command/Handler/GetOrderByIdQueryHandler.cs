﻿using EShop.Application.Order;
using EShop.Core.Entities;
using MediatR;
using OnlineLibraryShop.Core.Interfaces;

namespace OnlineLibraryShop.Application.Command.Handler
{
    public class GetOrderByIdQueryHandler : IRequestHandler<GetOrderByIdQuery, OrderDto>
    {
        private readonly IOrderRepository _orderRepository;
        public GetOrderByIdQueryHandler(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }
        public async Task<OrderDto> Handle(GetOrderByIdQuery request, CancellationToken cancellationToken)
        {
           return  await _orderRepository.GetPurchaseOrderDetail(request.OrderId);
        }
    }
}
