﻿using Dapper;
using EShop.Core.Entities;
using EShop.Core.Interfaces;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace EShop.Infrastructure.Repositories
{
    public class ProductRepository : IProductRepository
    {

        protected readonly IDbConnectionFactory _dbConnectionFactory;
        protected readonly IConfiguration _configuration;
        public ProductRepository(IDbConnectionFactory dbConnectionFactory, IConfiguration configuration)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _configuration = configuration;
        }

        public async Task<List<Product>> GetProductList()
        {
            List<Product> productList = new List<Product>();

            using (IDbConnection dbConnection = _dbConnectionFactory.CreateConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                dbConnection.Open();

                // Define the stored procedure call using Dapper
                IEnumerable<Product> products = await dbConnection.QueryAsync<Product>("GetAllProducts", commandType: CommandType.StoredProcedure);
                productList = products.ToList();
                return productList;
            }
        }
    }
}
